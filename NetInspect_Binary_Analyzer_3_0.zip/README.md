# NetInspect Binary Analyzer 3.0

Windows defensive binary triage tool.

Features:
- PE metadata, sections, imports, exports, strings, hex, entropy
- Heuristic indicators (not a malware verdict)
- Imports -> selected DLL static analysis
- Automated Windows metadata, signature, process and folder checks
- User-controlled Runtime Network monitoring
- Runtime process-tree tracking for the launched EXE and descendants
- 30/60/120/300 second observation windows
- JSON / HTML / TXT export

Opening/analyzing a file does not execute it. Runtime execution only happens after
the user presses **Run & Monitor**.

Install:
    py -m pip install -r requirements.txt
    python netinspect.py

Build:
    py -m pip install pyinstaller
    pyinstaller --clean --noconfirm --onefile --windowed --name NetInspect-Binary-Analyzer netinspect.py

Use only on software/files you are authorized to inspect.
