
import hashlib, math, os, re, struct, subprocess, threading, time, json
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP_NAME = "NetInspect Binary Analyzer"
APP_VERSION = "3.0.0"

def entropy(data):
    if not data: return 0.0
    counts=[0]*256
    for b in data: counts[b]+=1
    n=len(data)
    return -sum((c/n)*math.log2(c/n) for c in counts if c)

def file_hash(path, alg):
    h=hashlib.new(alg)
    with open(path,"rb") as f:
        for c in iter(lambda:f.read(1024*1024),b""): h.update(c)
    return h.hexdigest()

def sha256_file(p): return file_hash(p,"sha256")
def md5_file(p): return file_hash(p,"md5")

def safe_read(d,o,n):
    return d[o:o+n] if o is not None and o>=0 and n>=0 and o+n<=len(d) else None
def u16(d,o):
    x=safe_read(d,o,2); return struct.unpack("<H",x)[0] if x else None
def u32(d,o):
    x=safe_read(d,o,4); return struct.unpack("<I",x)[0] if x else None
def u64(d,o):
    x=safe_read(d,o,8); return struct.unpack("<Q",x)[0] if x else None
def cstr(d,o,m=512):
    if o is None or o<0 or o>=len(d): return ""
    e=d.find(b"\0",o,min(len(d),o+m))
    return d[o:e if e>=0 else min(len(d),o+m)].decode("latin-1","replace")

def ascii_strings(d, minimum=4):
    return [m.decode("latin-1","replace") for m in re.findall(rb"[\x20-\x7e]{%d,}"%minimum,d)]
def unicode_strings(d, minimum=4):
    out=[]
    for m in re.findall(rb"(?:[\x20-\x7e]\x00){%d,}"%minimum,d):
        try: out.append(m.decode("utf-16le","replace"))
        except: pass
    return out

def rva_to_offset(sections,rva):
    for s in sections:
        va=s["virtual_address"]; raw=s["raw_size"]
        if va<=rva<va+max(s["virtual_size"],raw):
            delta=rva-va
            if delta<raw: return s["raw_pointer"]+delta
    return None

class PEParser:
    def __init__(self,data):
        self.data=data; self.sections=[]; self.info={}; self.imports=[]; self.exports=[]
        self.parse()
    def parse(self):
        d=self.data
        if len(d)<0x40 or d[:2]!=b"MZ": raise ValueError("Not a valid MZ/PE file.")
        pe=u32(d,0x3c)
        if pe is None or safe_read(d,pe,4)!=b"PE\0\0": raise ValueError("Invalid PE signature.")
        coff=pe+4; machine=u16(d,coff); sc=u16(d,coff+2); ts=u32(d,coff+4)
        opts=u16(d,coff+16); chars=u16(d,coff+18); op=coff+20
        magic=u16(d,op); is64=magic==0x20b
        if magic not in (0x10b,0x20b): raise ValueError("Unsupported PE optional header.")
        ep=u32(d,op+16); base=u64(d,op+24) if is64 else u32(d,op+28)
        image=u32(d,op+56); subs=u16(d,op+68); dc=u16(d,op+70)
        dd=op+(112 if is64 else 96)
        ex=u32(d,dd) or 0; imp=u32(d,dd+8) or 0
        so=op+opts
        for i in range(sc):
            o=so+i*40; raw=safe_read(d,o,40)
            if not raw: break
            name=raw[:8].split(b"\0",1)[0].decode("latin-1","replace")
            vs=u32(raw,8) or 0; va=u32(raw,12) or 0; rs=u32(raw,16) or 0
            rp=u32(raw,20) or 0; ch=u32(raw,36) or 0
            blob=safe_read(d,rp,min(rs,max(0,len(d)-rp))) or b""
            self.sections.append(dict(name=name,virtual_size=vs,virtual_address=va,raw_size=rs,
                raw_pointer=rp,characteristics=ch,entropy=entropy(blob)))
        self.info={"Machine":{0x14c:"Intel 386 (I386)",0x8664:"x64",0x1c0:"ARM",0xaa64:"ARM64"}.get(machine,hex(machine)),
                   "Architecture":"PE32+" if is64 else "PE32","Sections":sc,
                   "Entry Point RVA":f"0x{ep:08X}","Image Base":f"0x{base:X}","Image Size":f"0x{image:X}",
                   "Subsystem":{2:"Windows GUI",3:"Windows Console"}.get(subs,str(subs)),
                   "Characteristics":f"0x{chars:04X}","DLL Characteristics":f"0x{dc:04X}",
                   "TimeDateStamp":ts,"Import RVA":f"0x{imp:08X}","Export RVA":f"0x{ex:08X}"}
        if imp:self.parse_imports(imp,is64)
        if ex:self.parse_exports(ex)
    def parse_imports(self,rva,is64):
        off=rva_to_offset(self.sections,rva)
        if off is None:return
        step=8 if is64 else 4
        for _ in range(512):
            desc=safe_read(self.data,off,20)
            if not desc:break
            oft=u32(desc,0) or 0; nr=u32(desc,12) or 0; ft=u32(desc,16) or 0
            if not(oft or nr or ft):break
            no=rva_to_offset(self.sections,nr); dll=cstr(self.data,no) if no is not None else "Unknown"
            funcs=[]; to=rva_to_offset(self.sections,oft or ft)
            if to is not None:
                for j in range(2048):
                    pos=to+j*step; val=u64(self.data,pos) if is64 else u32(self.data,pos)
                    if val is None or val==0:break
                    flag=(1<<63) if is64 else (1<<31)
                    if val&flag: funcs.append(f"Ordinal #{val&0xffff}")
                    else:
                        no=rva_to_offset(self.sections,int(val))
                        funcs.append(cstr(self.data,no+2) if no is not None else "Unknown")
            self.imports.append((dll,funcs)); off+=20
    def parse_exports(self,rva):
        o=rva_to_offset(self.sections,rva); b=safe_read(self.data,o,40) if o is not None else None
        if not b:return
        nc=u32(b,24) or 0; nr=u32(b,32) or 0
        no=rva_to_offset(self.sections,nr) if nr else None
        if no is None:return
        for i in range(min(nc,10000)):
            x=u32(self.data,no+i*4)
            if x is not None:
                xo=rva_to_offset(self.sections,x)
                if xo is not None:self.exports.append(cstr(self.data,xo))

SUSPICIOUS={"VirtualAlloc","VirtualProtect","WriteProcessMemory","CreateRemoteThread","NtWriteVirtualMemory",
"WinExec","ShellExecuteA","ShellExecuteW","URLDownloadToFileA","URLDownloadToFileW","InternetOpenA",
"InternetOpenW","WinHttpOpen","WinHttpConnect","RegSetValueExA","RegSetValueExW","CreateServiceA",
"CreateServiceW","WSAStartup","connect","InternetConnectA","HttpOpenRequestA"}

class Analyzer:
    def __init__(self,path,data,pe): self.path=path; self.data=data; self.pe=pe
    def findings(self):
        f=[]
        if self.pe:
            hs=[s["name"] for s in self.pe.sections if s["entropy"]>=7.2]
            if hs:f.append("High-entropy section(s): "+", ".join(hs))
            im={x for _,fs in self.pe.imports for x in fs}; hit=sorted(im&SUSPICIOUS)
            if hit:f.append("Behavior-relevant imports: "+", ".join(hit))
            names={s["name"].lower() for s in self.pe.sections}
            for n,hints in {"UPX":[b"UPX0",b"UPX1",b"UPX2"],"ASPack":[b".aspack",b"ASPack"],
                            "Themida":[b".themida",b"Themida"],"VMProtect":[b".vmp",b"VMProtect"]}.items():
                if any(h.lower() in names or h in self.data for h in hints):f.append("Packer/protector hint: "+n)
        if b"X5O!P%@AP" in self.data:f.append("EICAR test signature found (test pattern).")
        return f or ["No built-in heuristic indicators triggered."]

def version_info(path):
    script=r"""$i=Get-Item -LiteralPath $args[0];$v=$i.VersionInfo;[PSCustomObject]@{
Name=$i.Name;Length=$i.Length;CreationTime=$i.CreationTime;LastWriteTime=$i.LastWriteTime;
Company=$v.CompanyName;Product=$v.ProductName;FileVersion=$v.FileVersion;OriginalFilename=$v.OriginalFilename}|ConvertTo-Json -Compress"""
    try:return json.loads(subprocess.check_output(["powershell","-NoProfile","-Command",script,path],text=True,encoding="utf-8",errors="replace",timeout=15))
    except:return {}
def signature(path):
    script=r"""Get-AuthenticodeSignature -LiteralPath $args[0]|Select Status,StatusMessage,
@{N='Signer';E={$_.SignerCertificate.Subject}},@{N='Issuer';E={$_.SignerCertificate.Issuer}},
@{N='Thumbprint';E={$_.SignerCertificate.Thumbprint}}|ConvertTo-Json -Compress"""
    try:return json.loads(subprocess.check_output(["powershell","-NoProfile","-Command",script,path],text=True,encoding="utf-8",errors="replace",timeout=15))
    except:return {}

def net_connections():
    try:
        import psutil
        out=[]
        for c in psutil.net_connections(kind="inet"):
            local=f"{c.laddr.ip}:{c.laddr.port}" if c.laddr else "-"
            remote=f"{c.raddr.ip}:{c.raddr.port}" if c.raddr else "-"
            name="-"
            if c.pid:
                try:name=psutil.Process(c.pid).name()
                except:pass
            out.append((c.pid or 0,name,local,remote,c.status))
        return out
    except:return []

class App(tk.Tk):
    def __init__(self):
        super().__init__();self.title(f"{APP_NAME} | {APP_VERSION}");self.geometry("1360x860");self.minsize(1100,700);self.configure(bg="#151515")
        self.path=None;self.data=b"";self.pe=None;self.monitoring=False;self.runtime=None;self.runtime_rows=[];self.checks={};self.build()
    def style(self):
        s=ttk.Style(self)
        try:s.theme_use("clam")
        except:pass
        s.configure("TNotebook",background="#151515",borderwidth=0);s.configure("TNotebook.Tab",background="#303030",foreground="#ddd",padding=(13,7))
        s.map("TNotebook.Tab",background=[("selected","#168bd1")]);s.configure("Treeview",background="#202020",foreground="#ddd",fieldbackground="#202020",rowheight=24)
        s.configure("Treeview.Heading",background="#303030",foreground="#00e6c3")
    def build(self):
        self.style();top=tk.Frame(self,bg="#151515");top.pack(fill="x",padx=14,pady=10)
        tk.Label(top,text="◈",fg="#f2b544",bg="#151515",font=("Segoe UI",22,"bold")).pack(side="left")
        tk.Label(top,text=APP_NAME,fg="#f0f0f0",bg="#151515",font=("Segoe UI",18,"bold")).pack(side="left",padx=8)
        tk.Label(top,text="Static + User-Controlled Runtime Triage",fg="#888",bg="#151515").pack(side="left",pady=7)
        ttk.Button(top,text="Full Export",command=self.export).pack(side="right",padx=4);ttk.Button(top,text="Clear",command=self.clear).pack(side="right",padx=4);ttk.Button(top,text="Open File",command=self.open_file).pack(side="right",padx=4)
        self.path_var=tk.StringVar(value="No file selected");tk.Label(self,textvariable=self.path_var,anchor="w",fg="#00e6c3",bg="#1c1c1c",padx=10,pady=7).pack(fill="x",padx=14)
        self.nb=ttk.Notebook(self);self.nb.pack(fill="both",expand=True,padx=14,pady=12)
        names=["File Info","PE","Sections","Imports","DLL Analyze","Strings","Hex","Entropy","Heuristics","System Checks","Runtime Network"]
        self.tabs={n:tk.Frame(self.nb,bg="#171717") for n in names}
        for n,t in self.tabs.items():self.nb.add(t,text=n)
        self.info=self.text(self.tabs["File Info"]);self.pebox=self.text(self.tabs["PE"]);self.strbox=self.text(self.tabs["Strings"]);self.hexbox=self.text(self.tabs["Hex"]);self.heurbox=self.text(self.tabs["Heuristics"])
        self.sectree=self.tree(self.tabs["Sections"],("Name","VA","Raw Size","Raw Offset","Characteristics","Entropy"))
        self.imptree=self.tree(self.tabs["Imports"],("DLL","Imported Functions"));self.enttree=self.tree(self.tabs["Entropy"],("Section","Size","Entropy","Assessment"))
        self.build_dll();self.build_checks();self.build_runtime()
        self.status=tk.StringVar(value="Ready");tk.Label(self,textvariable=self.status,fg="#999",bg="#151515",anchor="w").pack(fill="x",padx=14,pady=(0,8))
    def text(self,p):
        f=tk.Frame(p,bg="#171717");f.pack(fill="both",expand=True,padx=8,pady=8);b=tk.Text(f,bg="#111",fg="#ddd",insertbackground="white",font=("Consolas",10),wrap="none",relief="flat")
        y=ttk.Scrollbar(f,command=b.yview);x=ttk.Scrollbar(f,orient="horizontal",command=b.xview);b.configure(yscrollcommand=y.set,xscrollcommand=x.set)
        b.grid(row=0,column=0,sticky="nsew");y.grid(row=0,column=1,sticky="ns");x.grid(row=1,column=0,sticky="ew");f.rowconfigure(0,weight=1);f.columnconfigure(0,weight=1);return b
    def tree(self,p,cols):
        f=tk.Frame(p,bg="#171717");f.pack(fill="both",expand=True,padx=8,pady=8);t=ttk.Treeview(f,columns=cols,show="headings")
        for c in cols:t.heading(c,text=c);t.column(c,width=180,anchor="w")
        y=ttk.Scrollbar(f,command=t.yview);x=ttk.Scrollbar(f,orient="horizontal",command=t.xview);t.configure(yscrollcommand=y.set,xscrollcommand=x.set)
        t.grid(row=0,column=0,sticky="nsew");y.grid(row=0,column=1,sticky="ns");x.grid(row=1,column=0,sticky="ew");f.rowconfigure(0,weight=1);f.columnconfigure(0,weight=1);return t
    def build_dll(self):
        t=self.tabs["DLL Analyze"];bar=tk.Frame(t,bg="#171717");bar.pack(fill="x",padx=8,pady=8);self.dllvar=tk.StringVar(value="Select an imported DLL")
        self.dllcombo=ttk.Combobox(bar,textvariable=self.dllvar,state="readonly",width=55);self.dllcombo.pack(side="left")
        ttk.Button(bar,text="Analyze Selected DLL",command=self.analyze_dll).pack(side="left",padx=6);ttk.Button(bar,text="Open DLL Manually",command=self.open_dll).pack(side="left");self.dllbox=self.text(t)
    def build_checks(self):
        t=self.tabs["System Checks"];bar=tk.Frame(t,bg="#171717");bar.pack(fill="x",padx=8,pady=8);ttk.Button(bar,text="Run All Checks",command=self.run_checks).pack(side="left");self.checkbox=self.text(t)
    def build_runtime(self):
        t=self.tabs["Runtime Network"];bar=tk.Frame(t,bg="#171717");bar.pack(fill="x",padx=8,pady=8)
        ttk.Button(bar,text="▶ Run & Monitor",command=self.start_runtime).pack(side="left");ttk.Button(bar,text="■ Stop Monitoring",command=self.stop_runtime).pack(side="left",padx=5);ttk.Button(bar,text="Terminate Target",command=self.terminate_runtime).pack(side="left")
        tk.Label(bar,text="Duration:",bg="#171717",fg="#bbb").pack(side="left",padx=(20,4));self.duration=tk.StringVar(value="60");ttk.Combobox(bar,textvariable=self.duration,values=["30","60","120","300"],width=7,state="readonly").pack(side="left")
        self.rtstatus=tk.StringVar(value="Idle — target will NOT run until you click Run & Monitor");tk.Label(t,textvariable=self.rtstatus,fg="#00e6c3",bg="#171717",anchor="w").pack(fill="x",padx=10)
        self.rttree=self.tree(t,("Time","PID","Process","Local","Remote","Status"))
    def settext(self,b,s):b.delete("1.0","end");b.insert("1.0",s)
    def open_file(self):
        p=filedialog.askopenfilename(filetypes=[("Executable / Binary","*.exe *.dll *.sys *.ocx *.scr *.com *.bin"),("All files","*.*")])
        if p:self.analyze(p)
    def open_dll(self):
        p=filedialog.askopenfilename(filetypes=[("DLL","*.dll"),("All files","*.*")])
        if p:self.analyze_dll_path(p)
    def analyze(self,p):
        try:
            with open(p,"rb") as f:d=f.read()
            self.path=p;self.data=d;self.pe=PEParser(d) if d[:2]==b"MZ" else None;self.populate();self.status.set(f"Analyzed {os.path.basename(p)} | {len(d):,} bytes")
        except Exception as e:messagebox.showerror("Analysis Error",str(e))
    def clear(self):
        self.stop_runtime();self.path=None;self.data=b"";self.pe=None;self.path_var.set("No file selected")
        for b in [self.info,self.pebox,self.strbox,self.hexbox,self.heurbox,self.dllbox,self.checkbox]:self.settext(b,"")
        for t in [self.sectree,self.imptree,self.enttree,self.rttree]:
            for i in t.get_children():t.delete(i)
        self.status.set("Ready")
    def populate(self):
        self.path_var.set(self.path);size=len(self.data)
        self.settext(self.info,"\n".join([f"File name       : {os.path.basename(self.path)}",f"Full path       : {self.path}",f"File size       : {size:,} bytes ({size/1024/1024:.2f} MiB)",f"MD5             : {md5_file(self.path)}",f"SHA-256         : {sha256_file(self.path)}",f"Overall entropy : {entropy(self.data):.4f}",f"File type       : {'PE executable' if self.pe else 'Unknown / non-PE'}"]))
        if self.pe:
            self.settext(self.pebox,"\n".join(f"{k:20}: {v}" for k,v in self.pe.info.items()))
            for t in [self.sectree,self.enttree,self.imptree]:
                for i in t.get_children():t.delete(i)
            for s in self.pe.sections:
                self.sectree.insert("", "end",values=(s["name"],f"0x{s['virtual_address']:08X}",s["raw_size"],f"0x{s['raw_pointer']:08X}",f"0x{s['characteristics']:08X}",f"{s['entropy']:.3f}"))
                a="Likely packed/compressed" if s["entropy"]>=7.2 else ("High entropy" if s["entropy"]>=6.8 else "Normal")
                self.enttree.insert("", "end",values=(s["name"],s["raw_size"],f"{s['entropy']:.3f}",a))
            for dll,fs in self.pe.imports:self.imptree.insert("", "end",values=(dll,", ".join(fs[:250])+(" ..." if len(fs)>250 else "")))
            dlls=[d for d,_ in self.pe.imports];self.dllcombo["values"]=dlls
            if dlls:self.dllcombo.current(0)
        strings=list(dict.fromkeys(ascii_strings(self.data)+unicode_strings(self.data)));self.settext(self.strbox,"\n".join(strings[:30000]))
        hex_lines=[]
        for o in range(0,min(len(self.data),16384),16):
            ch=self.data[o:o+16];hx=" ".join(f"{b:02X}" for b in ch);txt="".join(chr(b) if 32<=b<127 else "." for b in ch);hex_lines.append(f"{o:08X}  {hx:<47}  {txt}")
        self.settext(self.hexbox,"\n".join(hex_lines))
        self.settext(self.heurbox,"HEURISTIC TRIAGE\n================\n\n"+"\n".join("• "+x for x in Analyzer(self.path,self.data,self.pe).findings())+"\n\nNote: Heuristic indicators are not proof of malware.")
    def resolve_dll(self,n):
        c=[os.path.join(os.path.dirname(self.path),n),os.path.join(os.environ.get("WINDIR",r"C:\Windows"),"System32",n),os.path.join(os.environ.get("WINDIR",r"C:\Windows"),"SysWOW64",n)]
        return next((p for p in c if os.path.isfile(p)),None)
    def analyze_dll(self):
        n=self.dllvar.get();p=self.resolve_dll(n) if n else None
        if p:self.analyze_dll_path(p)
        else:messagebox.showinfo("DLL not found",f"Could not locate {n or 'the selected DLL'} automatically.\nUse Open DLL Manually.")
    def analyze_dll_path(self,p):
        try:
            with open(p,"rb") as f:d=f.read()
            pe=PEParser(d) if d[:2]==b"MZ" else None
            lines=[f"Selected DLL : {os.path.basename(p)}",f"Path          : {p}",f"Size          : {len(d):,}",f"MD5           : {md5_file(p)}",f"SHA-256       : {sha256_file(p)}",f"Entropy       : {entropy(d):.4f}",f"PE            : {'Yes' if pe else 'No'}",""]
            if pe:lines+=["PE METADATA"]+[f"{k:20}: {v}" for k,v in pe.info.items()]+["","IMPORTS"]+[f"{x}: {', '.join(fs[:120])}" for x,fs in pe.imports]
            lines+=["","SIGNATURE",json.dumps(signature(p),indent=2)];self.settext(self.dllbox,"\n".join(lines));self.nb.select(self.tabs["DLL Analyze"])
        except Exception as e:messagebox.showerror("DLL Analysis Error",str(e))
    def run_checks(self):
        if not self.path:return messagebox.showinfo("No file","Select a file first.")
        v=version_info(self.path);sig=signature(self.path);folder=os.path.dirname(self.path);inv=[]
        for fn in sorted(os.listdir(folder)):
            p=os.path.join(folder,fn)
            if os.path.isfile(p) and os.path.splitext(fn)[1].lower() in (".exe",".dll",".sys",".asi",".ocx",".scr"):
                try:inv.append((fn,os.path.getsize(p),sha256_file(p)))
                except:pass
        try:proc=subprocess.check_output(["tasklist","/fo","csv","/nh","/fi",f"IMAGENAME eq {os.path.basename(self.path)}"],text=True,encoding="utf-8",errors="replace")
        except:proc="Unavailable"
        lines=["AUTOMATED WINDOWS CHECKS","========================",f"Target: {self.path}","", "[Hash]",f"MD5     : {md5_file(self.path)}",f"SHA-256 : {sha256_file(self.path)}","", "[Version / File Metadata]",json.dumps(v,indent=2),"", "[Authenticode]",json.dumps(sig,indent=2),"","[Currently Running Instances]",proc.strip() or "None","", "[Related EXE/DLL/SYS/ASI Inventory]"]
        lines += [f"{n} | {s:,} bytes | SHA256 {h}" for n,s,h in inv];self.checks={"version":v,"signature":sig,"process":proc,"inventory":inv};self.settext(self.checkbox,"\n".join(lines));self.nb.select(self.tabs["System Checks"])
    def snapshot(self):
        out={}
        try:
            q='Get-CimInstance Win32_Process | Select ProcessId,ParentProcessId,Name | ConvertTo-Json -Compress'
            raw=subprocess.check_output(["powershell","-NoProfile","-Command",q],text=True,encoding="utf-8",errors="replace",timeout=15);a=json.loads(raw);a=a if isinstance(a,list) else [a]
            for x in a:out[int(x["ProcessId"])]=(x.get("Name",""),int(x.get("ParentProcessId") or 0))
        except:pass
        return out
    def descendants(self,root,snap):
        ids={root};changed=True
        while changed:
            changed=False
            for pid,(_,pp) in snap.items():
                if pp in ids and pid not in ids:ids.add(pid);changed=True
        return ids
    def start_runtime(self):
        if self.monitoring:return
        if not self.path:return messagebox.showinfo("No file","Select an EXE first.")
        if os.path.splitext(self.path)[1].lower()!=".exe":return messagebox.showinfo("Runtime","Run & Monitor is available for EXE targets.")
        try:self.runtime=subprocess.Popen([self.path],cwd=os.path.dirname(self.path),creationflags=getattr(subprocess,"CREATE_NEW_PROCESS_GROUP",0))
        except Exception as e:return messagebox.showerror("Launch failed",str(e))
        self.monitoring=True;self.runtime_rows=[];self.rt_end=time.time()+int(self.duration.get())
        for i in self.rttree.get_children():self.rttree.delete(i)
        self.rtstatus.set(f"Monitoring PID {self.runtime.pid} and descendants...");threading.Thread(target=self.monitor_loop,daemon=True).start()
    def monitor_loop(self):
        root=self.runtime.pid
        while self.monitoring and time.time()<self.rt_end:
            ids=self.descendants(root,self.snapshot());now=time.strftime("%H:%M:%S")
            rows=[(now,p,n,l,r,s) for p,n,l,r,s in net_connections() if p in ids]
            self.runtime_rows.extend(rows);self.after(0,self.refresh_runtime)
            left=max(0,int(self.rt_end-time.time()));self.after(0,lambda x=left,c=len(ids):self.rtstatus.set(f"Monitoring {c} related process(es) | remaining {x}s"))
            time.sleep(1)
        self.monitoring=False;self.after(0,lambda:self.rtstatus.set(f"Analysis complete — {len(self.runtime_rows)} network observations recorded."))
    def refresh_runtime(self):
        for i in self.rttree.get_children():self.rttree.delete(i)
        for r in self.runtime_rows[-500:]:self.rttree.insert("", "end",values=r)
    def stop_runtime(self):
        self.monitoring=False
        if hasattr(self,"rtstatus"):self.rtstatus.set("Monitoring stopped by user.")
    def terminate_runtime(self):
        if self.runtime and self.runtime.poll() is None:
            try:self.runtime.terminate()
            except:pass
        self.stop_runtime()
    def export(self):
        if not self.path:return messagebox.showinfo("Export","Select and analyze a file first.")
        base=filedialog.asksaveasfilename(defaultextension=".json",filetypes=[("JSON report","*.json"),("HTML report","*.html"),("Text report","*.txt")],initialfile=os.path.splitext(os.path.basename(self.path))[0]+"_NetInspect_Report")
        if not base:return
        report={"application":{"name":APP_NAME,"version":APP_VERSION},"target":self.path,"generated_at":time.strftime("%Y-%m-%dT%H:%M:%S"),"sha256":sha256_file(self.path),"md5":md5_file(self.path),"pe":self.pe.info if self.pe else None,"sections":self.pe.sections if self.pe else [],"imports":[{"DLL":d,"Imported Functions":f} for d,f in self.pe.imports] if self.pe else [],"heuristics":Analyzer(self.path,self.data,self.pe).findings() if self.pe else [],"system_checks":self.checks,"runtime_network":{"observations":self.runtime_rows,"note":"No observation does not prove absence of network capability."}}
        try:
            payload=json.dumps(report,indent=2,default=str)
            if base.lower().endswith(".html"):
                import html;payload="<html><body style='background:#111;color:#ddd;font-family:Consolas'><h1>NetInspect Report</h1><pre>"+html.escape(payload)+"</pre></body></html>"
            with open(base,"w",encoding="utf-8") as f:f.write(payload)
            messagebox.showinfo("Export complete",base)
        except Exception as e:messagebox.showerror("Export failed",str(e))

if __name__=="__main__":
    try: import psutil
    except ImportError:
        messagebox.showwarning("Dependency missing","Install psutil with: py -m pip install psutil")
    App().mainloop()
