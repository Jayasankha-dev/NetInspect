# NetInspect Binary Analyzer 2.0

Advanced defensive static + runtime triage utility for Windows.

## Features
- PE32/PE32+ identification, hashes, headers and sections
- Section entropy and heuristic triage
- Imports with **Analyze Selected DLL** and **Locate DLL** actions
- Automatic DLL resolution from the target directory, System32, SysWOW64 and PATH
- ASCII/UTF-16LE strings and hex preview
- PE exports
- Automated Windows metadata, Authenticode and current-process checks
- Runtime Network tab: launch selected file, capture PID and repeatedly inspect `netstat -ano` for that PID
- Full Export to JSON, TXT and CSV

## Requirements
Windows 10/11, Python 3.10+, Tkinter and PowerShell. No third-party Python package is required.

## Run
`python main.py`

## Build
`pyinstaller --clean --noconfirm --onefile --windowed --name "NetInspect Binary Analyzer" main.py`

Or run `build.bat`.

## Safety
Runtime execution is transparent and does not inject, patch, hide or modify the target process. Only run software you trust or are intentionally investigating.
