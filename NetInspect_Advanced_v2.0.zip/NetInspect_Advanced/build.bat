@echo off
python -m pip install --upgrade pyinstaller
pyinstaller --clean --noconfirm --onefile --windowed --name "NetInspect Binary Analyzer" main.py
pause
