import csv, hashlib, json, math, os, re, struct, subprocess, tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

APP_NAME='NetInspect Binary Analyzer'; APP_VERSION='2.0.0'

def entropy(data):
    if not data:return 0.0
    c=[0]*256
    for b in data:c[b]+=1
    n=len(data); return -sum((x/n)*math.log2(x/n) for x in c if x)

def file_hash(path, alg='sha256'):
    h=hashlib.new(alg)
    with open(path,'rb') as f:
        for ch in iter(lambda:f.read(1024*1024),b''):h.update(ch)
    return h.hexdigest()

def ascii_strings(data, minimum=4):
    return [m.decode('latin-1','replace') for m in re.compile(rb'[\x20-\x7e]{%d,}'%minimum).findall(data)]

def unicode_strings(data, minimum=4):
    out=[]
    for m in re.compile(rb'(?:[\x20-\x7e]\x00){%d,}'%minimum).findall(data):
        try:out.append(m.decode('utf-16le','replace'))
        except Exception:pass
    return out

def safe_read(d,o,n): return None if o<0 or n<0 or o+n>len(d) else d[o:o+n]
def u16(d,o):
    x=safe_read(d,o,2); return struct.unpack('<H',x)[0] if x else None
def u32(d,o):
    x=safe_read(d,o,4); return struct.unpack('<I',x)[0] if x else None
def u64(d,o):
    x=safe_read(d,o,8); return struct.unpack('<Q',x)[0] if x else None
def cstr(d,o,max_len=512):
    if o is None or o<0 or o>=len(d):return ''
    e=d.find(b'\0',o,min(len(d),o+max_len)); e=min(len(d),o+max_len) if e<0 else e
    return d[o:e].decode('latin-1','replace')
def rva_to_offset(sections,rva):
    for s in sections:
        if s['virtual_address']<=rva<s['virtual_address']+max(s['virtual_size'],s['raw_size']):
            delta=rva-s['virtual_address']
            if delta<s['raw_size']:return s['raw_pointer']+delta
    return None

def run_cmd(cmd,timeout=10):
    try:
        p=subprocess.run(cmd,capture_output=True,text=True,errors='replace',timeout=timeout,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        return p.returncode,(p.stdout or '')+(p.stderr or '')
    except Exception as e:return -1,'ERROR: '+str(e)
def psq(s):return "'"+str(s).replace("'","''")+"'"
def powershell(script,timeout=15):return run_cmd(['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',script],timeout)

class PEParser:
    def __init__(self,data):self.data=data;self.sections=[];self.info={};self.imports=[];self.exports=[];self.parse()
    def parse(self):
        d=self.data
        if len(d)<0x40 or d[:2]!=b'MZ':raise ValueError('Not a valid DOS/PE file: missing MZ header.')
        pe=u32(d,0x3c)
        if pe is None or safe_read(d,pe,4)!=b'PE\0\0':raise ValueError('Invalid PE signature.')
        coff=pe+4; machine=u16(d,coff); sc=u16(d,coff+2); ts=u32(d,coff+4); osz=u16(d,coff+16); chars=u16(d,coff+18); opt=coff+20
        magic=u16(d,opt); is64=magic==0x20b; is32=magic==0x10b
        if not(is32 or is64):raise ValueError('Unsupported PE optional-header magic.')
        ep=u32(d,opt+16); base=u64(d,opt+24) if is64 else u32(d,opt+28); image=u32(d,opt+56); sub=u16(d,opt+68); dc=u16(d,opt+70)
        dd=opt+(112 if is64 else 96); ex=u32(d,dd) or 0; imp=u32(d,dd+8) or 0; so=opt+osz
        for i in range(sc):
            raw=safe_read(d,so+i*40,40)
            if not raw:break
            name=raw[:8].split(b'\0',1)[0].decode('latin-1','replace'); vs=u32(raw,8) or 0; va=u32(raw,12) or 0; rs=u32(raw,16) or 0; rp=u32(raw,20) or 0; ch=u32(raw,36) or 0
            blob=safe_read(d,rp,min(rs,max(0,len(d)-rp))) or b''
            self.sections.append({'name':name,'virtual_size':vs,'virtual_address':va,'raw_size':rs,'raw_pointer':rp,'characteristics':ch,'entropy':entropy(blob)})
        self.info={'Machine':{0x14c:'Intel 386 (I386)',0x8664:'x64',0x1c0:'ARM',0xaa64:'ARM64'}.get(machine,f'0x{machine:04X}'),'Architecture':'PE32+' if is64 else 'PE32','Sections':sc,'Entry Point RVA':f'0x{ep:08X}','Image Base':f'0x{base:X}','Image Size':f'0x{image:X}','Subsystem':{2:'Windows GUI',3:'Windows Console',9:'Windows CE',10:'EFI Application'}.get(sub,str(sub)),'Characteristics':f'0x{chars:04X}','DLL Characteristics':f'0x{dc:04X}','TimeDateStamp':ts,'Import RVA':f'0x{imp:08X}','Export RVA':f'0x{ex:08X}'}
        if imp:self.parse_imports(imp,is64)
        if ex:self.parse_exports(ex)
    def parse_imports(self,rva,is64):
        off=rva_to_offset(self.sections,rva)
        if off is None:return
        step=8 if is64 else 4
        for _ in range(512):
            desc=safe_read(self.data,off,20)
            if not desc:break
            oft=u32(desc,0) or 0; nr=u32(desc,12) or 0; ft=u32(desc,16) or 0
            if not(oft or nr or ft):break
            no=rva_to_offset(self.sections,nr); dll=cstr(self.data,no) if no is not None else 'Unknown'; funcs=[]; to=rva_to_offset(self.sections,oft or ft)
            if to is not None:
                for j in range(2048):
                    v=u64(self.data,to+j*step) if is64 else u32(self.data,to+j*step)
                    if v is None or v==0:break
                    flag=(1<<63) if is64 else (1<<31)
                    if v&flag:funcs.append(f'Ordinal #{v&0xffff}')
                    else:
                        np=rva_to_offset(self.sections,int(v)); funcs.append(cstr(self.data,np+2) if np is not None else 'Unknown')
            self.imports.append((dll,funcs));off+=20
    def parse_exports(self,rva):
        off=rva_to_offset(self.sections,rva)
        if off is None:return
        b=safe_read(self.data,off,40)
        if not b:return
        count=u32(b,24) or 0; nr=u32(b,32) or 0; oo=u32(b,36) or 0; no=rva_to_offset(self.sections,nr); ord_off=rva_to_offset(self.sections,oo)
        if no is None or ord_off is None:return
        for i in range(min(count,10000)):
            rv=u32(self.data,no+i*4); x=rva_to_offset(self.sections,rv) if rv is not None else None
            if x is not None:self.exports.append(cstr(self.data,x))

class Analyzer:
    SUSPICIOUS={'VirtualAlloc','VirtualProtect','WriteProcessMemory','CreateRemoteThread','NtWriteVirtualMemory','WinExec','ShellExecuteA','ShellExecuteW','URLDownloadToFileA','URLDownloadToFileW','InternetOpenA','InternetOpenW','WinHttpOpen','WinHttpConnect','RegSetValueExA','RegSetValueExW','CreateServiceA','CreateServiceW'}
    NETWORK={'socket','connect','WSAConnect','WSASocketA','WSASocketW','InternetOpenA','InternetOpenW','InternetConnectA','InternetConnectW','HttpOpenRequestA','HttpOpenRequestW','WinHttpOpen','WinHttpConnect','URLDownloadToFileA','URLDownloadToFileW','gethostbyname','getaddrinfo'}
    PACKERS={'UPX':[b'UPX0',b'UPX1',b'UPX2'],'ASPack':[b'.aspack',b'ASPack'],'Themida':[b'.themida',b'Themida'],'VMProtect':[b'.vmp',b'VMProtect']}
    def __init__(self,path,data,pe):self.path=path;self.data=data;self.pe=pe
    def heuristic_lines(self):
        f=[]
        if self.pe:
            hi=[s for s in self.pe.sections if s['entropy']>=7.2]
            if hi:f.append('High-entropy section(s): '+', '.join(s['name'] for s in hi))
            im=set(x for _,fs in self.pe.imports for x in fs); a=sorted(im&self.SUSPICIOUS); n=sorted(im&self.NETWORK)
            if a:f.append('Behavior-relevant imports: '+', '.join(a))
            if n:f.append('Network-related imports: '+', '.join(n))
            names={s['name'].lower() for s in self.pe.sections}
            for p,hints in self.PACKERS.items():
                if any(h.lower() in names or h in self.data for h in hints):f.append('Packer/protector hint: '+p)
            dc=int(self.pe.info.get('DLL Characteristics','0'),16)
            if dc&0x40:f.append('ASLR flag present')
            if dc&0x100:f.append('NX/DEP flag present')
            if dc&0x4000:f.append('Control Flow Guard flag present')
        if b'X5O!P%@AP' in self.data:f.append('EICAR test signature found (test pattern, not malware).')
        return f or ['No built-in heuristic indicators triggered.']

class App(tk.Tk):
    def __init__(self):
        super().__init__();self.title(f'{APP_NAME} | {APP_VERSION}');self.geometry('1450x900');self.minsize(1100,720);self.configure(bg='#151515')
        self.path=None;self.data=b'';self.pe=None;self.runtime_proc=None;self.runtime_pid=None;self.runtime_running=False;self.runtime_snapshots=[];self.build_ui()
    def style(self):
        s=ttk.Style(self)
        try:s.theme_use('clam')
        except tk.TclError:pass
        s.configure('TNotebook',background='#151515',borderwidth=0);s.configure('TNotebook.Tab',background='#303030',foreground='#ddd',padding=(14,7));s.map('TNotebook.Tab',background=[('selected','#168bd1')]);s.configure('Treeview',background='#202020',foreground='#ddd',fieldbackground='#202020',rowheight=25);s.configure('Treeview.Heading',background='#303030',foreground='#00e6c3')
    def build_ui(self):
        self.style();top=tk.Frame(self,bg='#151515');top.pack(fill='x',padx=14,pady=10);tk.Label(top,text='◈',fg='#f2b544',bg='#151515',font=('Segoe UI',22,'bold')).pack(side='left',padx=(0,8));tk.Label(top,text=APP_NAME,fg='#f0f0f0',bg='#151515',font=('Segoe UI',18,'bold')).pack(side='left');tk.Label(top,text=f'  Advanced Static + Runtime Triage  v{APP_VERSION}',fg='#8f8f8f',bg='#151515').pack(side='left',pady=8)
        ttk.Button(top,text='Open File',command=self.open_file).pack(side='right',padx=4);ttk.Button(top,text='Full Export',command=self.full_export).pack(side='right',padx=4);ttk.Button(top,text='Clear',command=self.clear).pack(side='right',padx=4)
        self.path_var=tk.StringVar(value='No file selected');tk.Label(self,textvariable=self.path_var,anchor='w',fg='#00e6c3',bg='#1c1c1c',padx=10,pady=7).pack(fill='x',padx=14)
        self.nb=ttk.Notebook(self);self.nb.pack(fill='both',expand=True,padx=14,pady=12)
        tabs=[('File Info','info'),('PE','pe'),('Sections','sec'),('Imports','imp'),('Strings','str'),('Hex','hex'),('Entropy','ent'),('Heuristics','heur'),('Runtime Network','run'),('Automated Checks','check'),('Exports','exp')]
        for title,key in tabs:
            fr=tk.Frame(self.nb,bg='#171717');self.nb.add(fr,text=title);setattr(self,key+'_tab',fr)
        self.info_box=self.make_text(self.info_tab);self.pe_box=self.make_text(self.pe_tab);self.str_box=self.make_text(self.str_tab);self.hex_box=self.make_text(self.hex_tab);self.heur_box=self.make_text(self.heur_tab);self.check_box=self.make_text(self.check_tab);self.export_box=self.make_text(self.exp_tab)
        self.sec_tree=self.make_tree(self.sec_tab,('Name','VA','Raw Size','Raw Offset','Characteristics','Entropy'));self.ent_tree=self.make_tree(self.ent_tab,('Section','Size','Entropy','Assessment'))
        wrap=tk.Frame(self.imp_tab,bg='#171717');wrap.pack(fill='both',expand=True,padx=8,pady=8);bar=tk.Frame(wrap,bg='#171717');bar.pack(fill='x',pady=(0,6));ttk.Button(bar,text='Analyze Selected DLL',command=self.analyze_selected_dll).pack(side='left');ttk.Button(bar,text='Locate DLL...',command=self.locate_selected_dll).pack(side='left',padx=5);tk.Label(bar,text='Double-click a DLL row to analyze it statically.',fg='#999',bg='#171717').pack(side='left',padx=10);tw=tk.Frame(wrap,bg='#171717');tw.pack(fill='both',expand=True);self.imp_tree=ttk.Treeview(tw,columns=('DLL','Imported Functions'),show='headings');self.imp_tree.heading('DLL',text='DLL');self.imp_tree.heading('Imported Functions',text='Imported Functions');self.imp_tree.column('DLL',width=250);self.imp_tree.column('Imported Functions',width=900);sy=ttk.Scrollbar(tw,orient='vertical',command=self.imp_tree.yview);sx=ttk.Scrollbar(tw,orient='horizontal',command=self.imp_tree.xview);self.imp_tree.configure(yscrollcommand=sy.set,xscrollcommand=sx.set);self.imp_tree.grid(row=0,column=0,sticky='nsew');sy.grid(row=0,column=1,sticky='ns');sx.grid(row=1,column=0,sticky='ew');tw.rowconfigure(0,weight=1);tw.columnconfigure(0,weight=1);self.imp_tree.bind('<Double-1>',lambda e:self.analyze_selected_dll())
        self.build_runtime();self.status_var=tk.StringVar(value='Ready');bottom=tk.Frame(self,bg='#151515');bottom.pack(fill='x',padx=14,pady=(0,10));tk.Label(bottom,textvariable=self.status_var,fg='#999',bg='#151515').pack(side='left')
    def make_text(self,p):
        fr=tk.Frame(p,bg='#171717');fr.pack(fill='both',expand=True,padx=8,pady=8);b=tk.Text(fr,bg='#111',fg='#ddd',insertbackground='white',font=('Consolas',10),wrap='none',relief='flat');y=ttk.Scrollbar(fr,orient='vertical',command=b.yview);x=ttk.Scrollbar(fr,orient='horizontal',command=b.xview);b.configure(yscrollcommand=y.set,xscrollcommand=x.set);b.grid(row=0,column=0,sticky='nsew');y.grid(row=0,column=1,sticky='ns');x.grid(row=1,column=0,sticky='ew');fr.rowconfigure(0,weight=1);fr.columnconfigure(0,weight=1);return b
    def make_tree(self,p,cols):
        fr=tk.Frame(p,bg='#171717');fr.pack(fill='both',expand=True,padx=8,pady=8);t=ttk.Treeview(fr,columns=cols,show='headings');
        for c in cols:t.heading(c,text=c);t.column(c,width=170,anchor='w')
        y=ttk.Scrollbar(fr,orient='vertical',command=t.yview);x=ttk.Scrollbar(fr,orient='horizontal',command=t.xview);t.configure(yscrollcommand=y.set,xscrollcommand=x.set);t.grid(row=0,column=0,sticky='nsew');y.grid(row=0,column=1,sticky='ns');x.grid(row=1,column=0,sticky='ew');fr.rowconfigure(0,weight=1);fr.columnconfigure(0,weight=1);return t
    def build_runtime(self):
        top=tk.Frame(self.run_tab,bg='#171717');top.pack(fill='x',padx=8,pady=8);tk.Label(top,text='Launch the selected file and observe PID-scoped network connections using netstat -ano.',fg='#ddd',bg='#171717').pack(side='left');ttk.Button(top,text='Launch Selected',command=self.launch_selected).pack(side='right',padx=4);ttk.Button(top,text='Stop Process',command=self.stop_runtime).pack(side='right',padx=4);ttk.Button(top,text='Refresh Now',command=self.refresh_runtime).pack(side='right',padx=4);tk.Label(self.run_tab,text='Safety: run only trusted or intentionally investigated files. No injection, patching, hiding, or modification is performed.',fg='#e0b060',bg='#171717').pack(fill='x',padx=10);self.runtime_tree=self.make_tree(self.run_tab,('PID','Process','Local Address','Remote Address','State','Protocol'));self.runtime_log=self.make_text(self.run_tab);self.runtime_log.master.pack_forget();self.runtime_log.master.pack(fill='both',expand=False,padx=8,pady=(0,8));self.runtime_log.master.configure(height=150)
    def open_file(self):
        p=filedialog.askopenfilename(title='Select a file',filetypes=[('Executable / Binary','*.exe *.dll *.sys *.ocx *.scr *.com *.bin'),('All files','*.*')]);
        if p:self.analyze(p)
    def clear(self):
        self.stop_runtime();self.path=None;self.data=b'';self.pe=None;self.path_var.set('No file selected');self.runtime_snapshots=[]
        for b in [self.info_box,self.pe_box,self.str_box,self.hex_box,self.heur_box,self.check_box,self.export_box,self.runtime_log]:b.delete('1.0','end')
        for t in [self.sec_tree,self.imp_tree,self.ent_tree,self.runtime_tree]:
            for i in t.get_children():t.delete(i)
        self.status_var.set('Ready')
    def analyze(self,path):
        try:
            with open(path,'rb') as f:d=f.read()
            self.path=os.path.abspath(path);self.data=d;self.pe=PEParser(d) if d[:2]==b'MZ' else None;self.populate();self.path_var.set(self.path);self.nb.select(self.info_tab);self.status_var.set(f'Analyzed {os.path.basename(path)} | {len(d):,} bytes')
        except Exception as e:messagebox.showerror('Analysis Error',str(e));self.status_var.set('Analysis failed')
    def set_text(self,b,s):b.delete('1.0','end');b.insert('1.0',s)
    def populate(self):
        size=len(self.data);self.set_text(self.info_box,'\n'.join([f'File name       : {os.path.basename(self.path)}',f'Full path       : {self.path}',f'File size       : {size:,} bytes ({size/1048576:.2f} MiB)',f'MD5             : {file_hash(self.path,"md5")}',f'SHA-256         : {file_hash(self.path)}',f'Overall entropy : {entropy(self.data):.4f}',f'File type       : {"PE executable" if self.pe else "Unknown / non-PE"}']))
        if self.pe:
            self.set_text(self.pe_box,'\n'.join(f'{k:20}: {v}' for k,v in self.pe.info.items()))
            for t in [self.sec_tree,self.ent_tree,self.imp_tree]:
                for i in t.get_children():t.delete(i)
            for s in self.pe.sections:
                self.sec_tree.insert('','end',values=(s['name'],f"0x{s['virtual_address']:08X}",s['raw_size'],f"0x{s['raw_pointer']:08X}",f"0x{s['characteristics']:08X}",f"{s['entropy']:.3f}"));a='Likely packed/compressed' if s['entropy']>=7.2 else ('High entropy' if s['entropy']>=6.8 else 'Normal');self.ent_tree.insert('','end',values=(s['name'],s['raw_size'],f"{s['entropy']:.3f}",a))
            for dll,funcs in self.pe.imports:self.imp_tree.insert('','end',values=(dll,', '.join(funcs[:300])+(' ...' if len(funcs)>300 else '')))
        self.set_text(self.str_box,'\n'.join(list(dict.fromkeys(ascii_strings(self.data)+unicode_strings(self.data)))[:30000]));lines=[]
        for off in range(0,min(len(self.data),32768),16):
            ch=self.data[off:off+16];lines.append(f"{off:08X}  {' '.join(f'{b:02X}' for b in ch):<47}  {''.join(chr(b) if 32<=b<127 else '.' for b in ch)}")
        self.set_text(self.hex_box,'\n'.join(lines));self.set_text(self.heur_box,'HEURISTIC TRIAGE\n================\n\n'+'\n'.join('• '+x for x in (Analyzer(self.path,self.data,self.pe).heuristic_lines() if self.pe else ['No PE structure detected; generic binary analysis only.']))+'\n\nNote: Heuristic indicators are not proof of malware.');self.populate_exports();self.run_checks()
    def selected_dll(self):
        s=self.imp_tree.selection();return self.imp_tree.item(s[0],'values')[0] if s else None
    def resolve_dll(self,name):
        if not name:return None
        windir=os.environ.get('WINDIR',r'C:\Windows');c=[Path(self.path).parent/name,Path(windir)/'System32'/name,Path(windir)/'SysWOW64'/name]
        c += [Path(x)/name for x in os.environ.get('PATH','').split(os.pathsep) if x]
        for x in c:
            try:
                if x.is_file():return str(x.resolve())
            except Exception:pass
        return None
    def analyze_selected_dll(self):
        n=self.selected_dll()
        if not n:return messagebox.showinfo('Imports','Select a DLL row first.')
        p=self.resolve_dll(n)
        if p:self.analyze(p)
        else:messagebox.showinfo('DLL not found',f'Could not resolve {n}. Use Locate DLL...')
    def locate_selected_dll(self):
        n=self.selected_dll()
        if not n:return messagebox.showinfo('Imports','Select a DLL row first.')
        p=filedialog.askopenfilename(title=f'Locate {n}',filetypes=[('DLL files','*.dll'),('All files','*.*')]);
        if p:self.analyze(p)
    def run_checks(self):
        p=self.path;out=[f'AUTOMATED WINDOWS CHECKS\n========================\nTimestamp: {datetime.now().isoformat(timespec="seconds")}\nTarget: {p}\n']
        _,x=powershell(f"$p={psq(p)};$i=Get-Item -LiteralPath $p -ErrorAction Stop;$v=$i.VersionInfo;[PSCustomObject]@{{Name=$i.Name;Length=$i.Length;CreationTime=$i.CreationTime;LastWriteTime=$i.LastWriteTime;Company=$v.CompanyName;Product=$v.ProductName;FileVersion=$v.FileVersion;OriginalFilename=$v.OriginalFilename}}|Format-List *");out += ['[Version / File Metadata]',x.strip(),'']
        _,x=powershell(f"Get-AuthenticodeSignature -LiteralPath {psq(p)}|Format-List Status,StatusMessage,SignerCertificate");out += ['[Authenticode Signature]',x.strip(),'']
        _,x=powershell(f"Get-CimInstance Win32_Process|Where-Object {{$_.ExecutablePath -eq {psq(p)}}}|Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine|Format-List *");out += ['[Currently Running Instances]',x.strip(),''];self.set_text(self.check_box,'\n'.join(out))
    def clear_runtime(self):
        for i in self.runtime_tree.get_children():self.runtime_tree.delete(i)
    def log(self,s):self.runtime_log.insert('end',s+'\n');self.runtime_log.see('end')
    def launch_selected(self):
        if not self.path:return messagebox.showinfo('Runtime','Select a file first.')
        if self.runtime_proc and self.runtime_proc.poll() is None:return messagebox.showinfo('Runtime',f'Already running PID {self.runtime_proc.pid}.')
        try:
            self.runtime_running=True;self.runtime_snapshots=[];self.clear_runtime();self.runtime_proc=subprocess.Popen([self.path],cwd=os.path.dirname(self.path) or None,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0));self.runtime_pid=self.runtime_proc.pid;self.log(f'[{datetime.now():%H:%M:%S}] Launched {os.path.basename(self.path)} | PID={self.runtime_pid}');self.refresh_runtime();self.after(1000,self.runtime_tick)
        except Exception as e:self.runtime_running=False;messagebox.showerror('Launch Error',str(e))
    def runtime_tick(self):
        if not self.runtime_running:return
        if self.runtime_proc and self.runtime_proc.poll() is not None:self.log(f'[{datetime.now():%H:%M:%S}] Process exited | code={self.runtime_proc.returncode}');self.runtime_running=False;return
        self.refresh_runtime();self.after(1000,self.runtime_tick)
    def refresh_runtime(self):
        if not self.runtime_pid:return
        _,out=run_cmd(['netstat.exe','-ano'],10);rows=[]
        for line in out.splitlines():
            p=re.split(r'\s+',line.strip())
            if len(p)<4 or p[0].upper() not in ('TCP','TCPv6','UDP','UDPv6'):continue
            proto=p[0].upper()
            if proto.startswith('TCP'):
                if len(p)<5:continue
                la,ra,state,rpid=p[1],p[2],p[3],p[4]
            else:la,ra,state,rpid=p[1],'*:*','',p[3]
            if str(rpid)==str(self.runtime_pid):rows.append((str(rpid),os.path.basename(self.path or ''),la,ra,state,proto))
        self.clear_runtime()
        for r in rows:self.runtime_tree.insert('','end',values=r)
        self.runtime_snapshots.append({'timestamp':datetime.now().isoformat(timespec='seconds'),'pid':self.runtime_pid,'connections':[list(r) for r in rows]});self.log(f'[{datetime.now():%H:%M:%S}] {len(rows)} connection(s) observed for PID {self.runtime_pid}')
    def stop_runtime(self):
        self.runtime_running=False
        if self.runtime_proc and self.runtime_proc.poll() is None:
            try:self.runtime_proc.terminate();self.runtime_proc.wait(timeout=3)
            except Exception:
                try:self.runtime_proc.kill()
                except Exception:pass
        self.runtime_proc=None;self.runtime_pid=None
    def populate_exports(self):self.set_text(self.export_box,'\n'.join(f'{i+1:5d}  {x}' for i,x in enumerate(self.pe.exports)) if self.pe and self.pe.exports else ('PE parsed successfully, but no named exports were found.' if self.pe else 'No PE export table detected.'))
    def report(self):
        def rows(t):return [dict(zip(t['columns'],t.item(i,'values'))) for i in t.get_children()]
        return {'application':{'name':APP_NAME,'version':APP_VERSION},'generated_at':datetime.now().isoformat(timespec='seconds'),'target':self.path,'file_info':self.info_box.get('1.0','end').strip(),'pe':self.pe_box.get('1.0','end').strip(),'sections':rows(self.sec_tree),'imports':rows(self.imp_tree),'strings':self.str_box.get('1.0','end').strip(),'hex':self.hex_box.get('1.0','end').strip(),'entropy':rows(self.ent_tree),'heuristics':self.heur_box.get('1.0','end').strip(),'automated_checks':self.check_box.get('1.0','end').strip(),'exports':self.export_box.get('1.0','end').strip(),'runtime_network':{'snapshots':self.runtime_snapshots,'log':self.runtime_log.get('1.0','end').strip()}}
    def full_export(self):
        if not self.path:return messagebox.showinfo('Export','Select and analyze a file first.')
        folder=filedialog.askdirectory(title='Choose export folder');
        if not folder:return
        r=self.report();base=Path(folder)/(Path(self.path).stem+'_NetInspect_'+datetime.now().strftime('%Y%m%d_%H%M%S'));jp=str(base)+'.json';tp=str(base)+'.txt';cp=str(base)+'.csv'
        Path(jp).write_text(json.dumps(r,indent=2,ensure_ascii=False),encoding='utf-8')
        with open(tp,'w',encoding='utf-8') as f:
            f.write(APP_NAME+' '+APP_VERSION+'\n'+'='*80+'\n');
            for k in ['file_info','pe','heuristics','automated_checks','exports','strings','hex']:f.write(f'\n### {k.upper()} ###\n{r[k]}\n')
            for k in ['sections','imports','entropy']:f.write(f'\n### {k.upper()} ###\n'+'\n'.join(' | '.join(map(str,x.values())) for x in r[k])+'\n')
            f.write('\n### RUNTIME NETWORK ###\n'+r['runtime_network']['log']+'\n')
        with open(cp,'w',newline='',encoding='utf-8') as f:
            w=csv.writer(f);w.writerow(['Category','Field','Value'])
            for k in ['file_info','pe','heuristics','automated_checks','exports']:
                for line in r[k].splitlines():
                    a=line.split(':',1);w.writerow([k,a[0].strip() if len(a)>1 else '',a[1].strip() if len(a)>1 else line])
            for k in ['sections','imports','entropy']:
                for x in r[k]:
                    for a,b in x.items():w.writerow([k,a,b])
        messagebox.showinfo('Export Complete',f'Full report exported:\n\n{jp}\n{tp}\n{cp}');self.status_var.set('Full export completed')

if __name__=='__main__':App().mainloop()
