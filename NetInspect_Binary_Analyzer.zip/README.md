# NetInspect Binary Analyzer

A standalone, original static-analysis GUI inspired by the workflow shown in the reference screenshots. It is **not** a copy of Detect It Easy and does not include its proprietary assets, signatures, or database.

## Features

- PE32 / PE32+ identification
- DOS/PE header inspection
- Entry point, image base, subsystem and flags
- Section table
- Per-section entropy
- Import table extraction
- ASCII and UTF-16LE strings
- Hex viewer
- MD5 and SHA-256
- Basic heuristic triage
- Suspicious import indicators
- Packer/protector hints
- ASLR / NX / CFG flag display
- EICAR test-pattern recognition
- Windows GUI
- No network upload or automatic sample submission

## Run

Python 3.10+ is recommended.

```bat
python main.py
```

## Build a Windows EXE

Install PyInstaller:

```bat
python -m pip install pyinstaller
```

Then:

```bat
pyinstaller --clean --noconfirm --onefile --windowed --name NetInspect-Binary-Analyzer main.py
```

The EXE will be in:

```text
dist\NetInspect-Binary-Analyzer.exe
```

## Design

The UI intentionally follows a familiar reverse-engineering workflow: file selection, file metadata, PE information, sections, imports, strings, entropy, hex data, and heuristic triage.

For production-grade signature databases, use the original Detect It Easy project and its official releases.
