import hashlib
import math
import os
import re
import struct
import subprocess
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP_NAME = "NetInspect Binary Analyzer"
APP_VERSION = "1.0.0"


def entropy(data: bytes) -> float:
    if not data:
        return 0.0
    counts = [0] * 256
    for b in data:
        counts[b] += 1
    n = len(data)
    return -sum((c / n) * math.log2(c / n) for c in counts if c)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def md5_file(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def ascii_strings(data, minimum=4):
    pattern = re.compile(rb"[\x20-\x7e]{%d,}" % minimum)
    return [m.decode("latin-1", errors="replace") for m in pattern.findall(data)]


def unicode_strings(data, minimum=4):
    pattern = re.compile(
        rb"(?:[\x20-\x7e]\x00){%d,}" % minimum
    )
    result = []
    for m in pattern.findall(data):
        try:
            result.append(m.decode("utf-16le", errors="replace"))
        except Exception:
            pass
    return result


def safe_read(data, offset, size):
    if offset < 0 or size < 0 or offset + size > len(data):
        return None
    return data[offset:offset + size]


def u16(data, off):
    x = safe_read(data, off, 2)
    return struct.unpack("<H", x)[0] if x else None


def u32(data, off):
    x = safe_read(data, off, 4)
    return struct.unpack("<I", x)[0] if x else None


def u64(data, off):
    x = safe_read(data, off, 8)
    return struct.unpack("<Q", x)[0] if x else None


def cstr(data, off, max_len=512):
    if off is None or off < 0 or off >= len(data):
        return ""
    end = data.find(b"\x00", off, min(len(data), off + max_len))
    if end < 0:
        end = min(len(data), off + max_len)
    return data[off:end].decode("latin-1", errors="replace")


def rva_to_offset(sections, rva):
    for s in sections:
        va = s["virtual_address"]
        raw = s["raw_size"]
        if va <= rva < va + max(s["virtual_size"], raw):
            delta = rva - va
            if delta < raw:
                return s["raw_pointer"] + delta
    return None


class PEParser:
    def __init__(self, data):
        self.data = data
        self.sections = []
        self.info = {}
        self.imports = []
        self.exports = []
        self.parse()

    def parse(self):
        d = self.data
        if len(d) < 0x40 or d[:2] != b"MZ":
            raise ValueError("Not a valid DOS/PE file: missing MZ header.")

        pe_off = u32(d, 0x3C)
        if pe_off is None or safe_read(d, pe_off, 4) != b"PE\x00\x00":
            raise ValueError("Invalid PE signature.")

        coff = pe_off + 4
        machine = u16(d, coff)
        section_count = u16(d, coff + 2)
        timestamp = u32(d, coff + 4)
        opt_size = u16(d, coff + 16)
        characteristics = u16(d, coff + 18)
        opt = coff + 20

        magic = u16(d, opt)
        is64 = magic == 0x20B
        is32 = magic == 0x10B
        if not (is32 or is64):
            raise ValueError("Unsupported PE optional-header magic.")

        entry_rva = u32(d, opt + 16)
        image_base = u64(d, opt + 24) if is64 else u32(d, opt + 28)
        image_size = u32(d, opt + 56)
        subsystem = u16(d, opt + 68)
        dll_chars = u16(d, opt + 70)

        data_dir = opt + (112 if is64 else 96)
        import_rva = u32(d, data_dir + 8) or 0
        import_size = u32(d, data_dir + 12) or 0
        export_rva = u32(d, data_dir) or 0
        export_size = u32(d, data_dir + 4) or 0

        sec_off = opt + opt_size
        for i in range(section_count):
            off = sec_off + i * 40
            raw = safe_read(d, off, 40)
            if not raw:
                break
            name = raw[:8].split(b"\x00", 1)[0].decode("latin-1", errors="replace")
            virtual_size = u32(raw, 8) or 0
            virtual_address = u32(raw, 12) or 0
            raw_size = u32(raw, 16) or 0
            raw_pointer = u32(raw, 20) or 0
            chars = u32(raw, 36) or 0
            blob = safe_read(d, raw_pointer, min(raw_size, max(0, len(d) - raw_pointer))) or b""
            self.sections.append({
                "name": name,
                "virtual_size": virtual_size,
                "virtual_address": virtual_address,
                "raw_size": raw_size,
                "raw_pointer": raw_pointer,
                "characteristics": chars,
                "entropy": entropy(blob),
            })

        self.info = {
            "Machine": {0x14C: "Intel 386 (I386)", 0x8664: "x64", 0x1C0: "ARM", 0xAA64: "ARM64"}.get(machine, f"0x{machine:04X}"),
            "Architecture": "PE32+" if is64 else "PE32",
            "Sections": section_count,
            "Entry Point RVA": f"0x{entry_rva:08X}",
            "Image Base": f"0x{image_base:X}",
            "Image Size": f"0x{image_size:X}",
            "Subsystem": {2: "Windows GUI", 3: "Windows Console", 9: "Windows CE", 10: "EFI Application"}.get(subsystem, str(subsystem)),
            "Characteristics": f"0x{characteristics:04X}",
            "DLL Characteristics": f"0x{dll_chars:04X}",
            "TimeDateStamp": timestamp,
            "Import RVA": f"0x{import_rva:08X}",
            "Export RVA": f"0x{export_rva:08X}",
        }

        if import_rva:
            self.parse_imports(import_rva, is64)
        if export_rva:
            self.parse_exports(export_rva)

    def parse_imports(self, rva, is64):
        off = rva_to_offset(self.sections, rva)
        if off is None:
            return
        step = 8 if is64 else 4
        for _ in range(512):
            desc = safe_read(self.data, off, 20)
            if not desc:
                break
            oft = u32(desc, 0) or 0
            name_rva = u32(desc, 12) or 0
            ft = u32(desc, 16) or 0
            if not (oft or name_rva or ft):
                break
            name_off = rva_to_offset(self.sections, name_rva)
            dll = cstr(self.data, name_off) if name_off is not None else "Unknown"
            funcs = []
            thunk_rva = oft or ft
            thunk_off = rva_to_offset(self.sections, thunk_rva)
            if thunk_off is not None:
                for j in range(2048):
                    pos = thunk_off + j * step
                    val = u64(self.data, pos) if is64 else u32(self.data, pos)
                    if val is None or val == 0:
                        break
                    ordinal_flag = (1 << 63) if is64 else (1 << 31)
                    if val & ordinal_flag:
                        funcs.append(f"Ordinal #{val & 0xFFFF}")
                    else:
                        name_ptr = rva_to_offset(self.sections, int(val))
                        funcs.append(cstr(self.data, name_ptr + 2) if name_ptr is not None else "Unknown")
            self.imports.append((dll, funcs))
            off += 20

    def parse_exports(self, rva):
        off = rva_to_offset(self.sections, rva)
        if off is None:
            return
        blob = safe_read(self.data, off, 40)
        if not blob:
            return
        name_count = u32(blob, 24) or 0
        addr_rva = u32(blob, 28) or 0
        name_rva = u32(blob, 32) or 0
        ord_rva = u32(blob, 36) or 0
        names_off = rva_to_offset(self.sections, name_rva)
        ord_off = rva_to_offset(self.sections, ord_rva)
        if names_off is None or ord_off is None:
            return
        for i in range(min(name_count, 10000)):
            nrva = u32(self.data, names_off + i * 4)
            ordv = u16(self.data, ord_off + i * 2)
            noff = rva_to_offset(self.sections, nrva) if nrva is not None else None
            if noff is not None:
                self.exports.append(cstr(self.data, noff))

    def import_names(self):
        return [dll for dll, _ in self.imports]


class Analyzer:
    SUSPICIOUS_IMPORTS = {
        "VirtualAlloc", "VirtualProtect", "WriteProcessMemory",
        "CreateRemoteThread", "NtWriteVirtualMemory",
        "WinExec", "ShellExecuteA", "ShellExecuteW",
        "URLDownloadToFileA", "URLDownloadToFileW",
        "InternetOpenA", "InternetOpenW", "WinHttpOpen",
        "WinHttpConnect", "RegSetValueExA", "RegSetValueExW",
        "CreateServiceA", "CreateServiceW",
    }

    PACKER_HINTS = {
        "UPX": [b"UPX0", b"UPX1", b"UPX2"],
        "ASPack": [b".aspack", b"ASPack"],
        "Themida": [b".themida", b"Themida"],
        "VMProtect": [b".vmp", b"VMProtect"],
    }

    def __init__(self, path, data, pe=None):
        self.path = path
        self.data = data
        self.pe = pe

    def heuristic_lines(self):
        findings = []
        if self.pe:
            high_entropy = [s for s in self.pe.sections if s["entropy"] >= 7.2]
            if high_entropy:
                findings.append(f"High-entropy section(s): {', '.join(s['name'] for s in high_entropy)}")

            imports = set()
            for _, funcs in self.pe.imports:
                imports.update(funcs)
            hits = sorted(imports & self.SUSPICIOUS_IMPORTS)
            if hits:
                findings.append("Behavior-relevant imports: " + ", ".join(hits))

            sec_names = {s["name"].lower() for s in self.pe.sections}
            for packer, hints in self.PACKER_HINTS.items():
                if any(h.lower() in sec_names or h in self.data for h in hints):
                    findings.append(f"Packer/protector hint: {packer}")

            if self.pe.info.get("DLL Characteristics", "").startswith("0x"):
                dc = int(self.pe.info["DLL Characteristics"], 16)
                if dc & 0x40:
                    findings.append("ASLR flag present")
                if dc & 0x100:
                    findings.append("NX/DEP flag present")
                if dc & 0x4000:
                    findings.append("Control Flow Guard flag present")

        if b"X5O!P%@AP" in self.data:
            findings.append("EICAR test signature found (test pattern, not malware).")

        if not findings:
            findings.append("No built-in heuristic indicators triggered.")

        return findings


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} | {APP_VERSION}")
        self.geometry("1280x820")
        self.minsize(1000, 680)
        self.configure(bg="#151515")

        self.path = None
        self.data = b""
        self.pe = None
        self.build_ui()

    def style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TNotebook", background="#151515", borderwidth=0)
        style.configure("TNotebook.Tab", background="#303030", foreground="#dddddd", padding=(14, 7))
        style.map("TNotebook.Tab", background=[("selected", "#168bd1")])
        style.configure("Treeview", background="#202020", foreground="#dddddd",
                        fieldbackground="#202020", rowheight=24)
        style.configure("Treeview.Heading", background="#303030", foreground="#00e6c3")
        style.map("Treeview", background=[("selected", "#087bc1")])

    def build_ui(self):
        self.style()

        top = tk.Frame(self, bg="#151515")
        top.pack(fill="x", padx=14, pady=10)

        tk.Label(top, text="◈", fg="#f2b544", bg="#151515",
                 font=("Segoe UI", 22, "bold")).pack(side="left", padx=(0, 8))
        tk.Label(top, text=APP_NAME, fg="#f0f0f0", bg="#151515",
                 font=("Segoe UI", 18, "bold")).pack(side="left")
        tk.Label(top, text="  Static File Identification & PE Triage",
                 fg="#8f8f8f", bg="#151515", font=("Segoe UI", 10)).pack(side="left", pady=8)

        ttk.Button(top, text="Open File", command=self.open_file).pack(side="right", padx=4)
        ttk.Button(top, text="Clear", command=self.clear).pack(side="right", padx=4)

        self.path_var = tk.StringVar(value="No file selected")
        tk.Label(self, textvariable=self.path_var, anchor="w",
                 fg="#00e6c3", bg="#1c1c1c", padx=10, pady=7).pack(fill="x", padx=14)

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=14, pady=12)

        self.file_tab = tk.Frame(self.notebook, bg="#171717")
        self.pe_tab = tk.Frame(self.notebook, bg="#171717")
        self.sec_tab = tk.Frame(self.notebook, bg="#171717")
        self.imp_tab = tk.Frame(self.notebook, bg="#171717")
        self.str_tab = tk.Frame(self.notebook, bg="#171717")
        self.hex_tab = tk.Frame(self.notebook, bg="#171717")
        self.ent_tab = tk.Frame(self.notebook, bg="#171717")
        self.heur_tab = tk.Frame(self.notebook, bg="#171717")

        for tab, title in [
            (self.file_tab, "File Info"), (self.pe_tab, "PE"),
            (self.sec_tab, "Sections"), (self.imp_tab, "Imports"),
            (self.str_tab, "Strings"), (self.hex_tab, "Hex"),
            (self.ent_tab, "Entropy"), (self.heur_tab, "Heuristics")
        ]:
            self.notebook.add(tab, text=title)

        self.info_box = self.make_text(self.file_tab)
        self.pe_box = self.make_text(self.pe_tab)
        self.str_box = self.make_text(self.str_tab)
        self.hex_box = self.make_text(self.hex_tab)
        self.heur_box = self.make_text(self.heur_tab)

        self.sec_tree = self.make_tree(
            self.sec_tab,
            ("Name", "VA", "Raw Size", "Raw Offset", "Characteristics", "Entropy")
        )
        self.imp_tree = self.make_tree(
            self.imp_tab,
            ("DLL", "Imported Functions")
        )

        self.ent_tree = self.make_tree(
            self.ent_tab,
            ("Section", "Size", "Entropy", "Assessment")
        )

        bottom = tk.Frame(self, bg="#151515")
        bottom.pack(fill="x", padx=14, pady=(0, 10))
        self.status_var = tk.StringVar(value="Ready")
        tk.Label(bottom, textvariable=self.status_var, fg="#9e9e9e",
                 bg="#151515", anchor="w").pack(side="left")

    def make_text(self, parent):
        frame = tk.Frame(parent, bg="#171717")
        frame.pack(fill="both", expand=True, padx=8, pady=8)
        box = tk.Text(frame, bg="#111111", fg="#dddddd", insertbackground="#ffffff",
                      font=("Consolas", 10), wrap="none", relief="flat")
        sy = ttk.Scrollbar(frame, orient="vertical", command=box.yview)
        sx = ttk.Scrollbar(frame, orient="horizontal", command=box.xview)
        box.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        box.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return box

    def make_tree(self, parent, columns):
        frame = tk.Frame(parent, bg="#171717")
        frame.pack(fill="both", expand=True, padx=8, pady=8)
        tree = ttk.Treeview(frame, columns=columns, show="headings")
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=170, anchor="w")
        y = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        x = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=y.set, xscrollcommand=x.set)
        tree.grid(row=0, column=0, sticky="nsew")
        y.grid(row=0, column=1, sticky="ns")
        x.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return tree

    def open_file(self):
        path = filedialog.askopenfilename(
            title="Select a file",
            filetypes=[
                ("Executable / Binary", "*.exe *.dll *.sys *.ocx *.scr *.com *.bin"),
                ("All files", "*.*"),
            ],
        )
        if path:
            self.analyze(path)

    def clear(self):
        self.path = None
        self.data = b""
        self.pe = None
        self.path_var.set("No file selected")
        for box in [self.info_box, self.pe_box, self.str_box, self.hex_box, self.heur_box]:
            box.delete("1.0", "end")
        for tree in [self.sec_tree, self.imp_tree, self.ent_tree]:
            for item in tree.get_children():
                tree.delete(item)
        self.status_var.set("Ready")

    def analyze(self, path):
        try:
            with open(path, "rb") as f:
                data = f.read()
            self.path = path
            self.data = data
            self.pe = PEParser(data) if data[:2] == b"MZ" else None
            self.populate()
            self.status_var.set(f"Analyzed {os.path.basename(path)} | {len(data):,} bytes")
            self.notebook.select(self.file_tab)
        except Exception as e:
            messagebox.showerror("Analysis Error", str(e))
            self.status_var.set("Analysis failed")

    def set_text(self, box, text):
        box.delete("1.0", "end")
        box.insert("1.0", text)

    def populate(self):
        size = len(self.data)
        avg_entropy = entropy(self.data)
        file_name = os.path.basename(self.path)

        info = [
            f"File name       : {file_name}",
            f"Full path       : {self.path}",
            f"File size       : {size:,} bytes ({size / 1024 / 1024:.2f} MiB)",
            f"MD5             : {md5_file(self.path)}",
            f"SHA-256         : {sha256_file(self.path)}",
            f"Overall entropy : {avg_entropy:.4f}",
            f"File type       : {'PE executable' if self.pe else 'Unknown / non-PE'}",
        ]
        self.set_text(self.info_box, "\n".join(info))

        if self.pe:
            self.set_text(
                self.pe_box,
                "\n".join(f"{k:20}: {v}" for k, v in self.pe.info.items())
            )

            for tree in [self.sec_tree, self.ent_tree]:
                for item in tree.get_children():
                    tree.delete(item)

            for s in self.pe.sections:
                chars = f"0x{s['characteristics']:08X}"
                self.sec_tree.insert(
                    "", "end",
                    values=(
                        s["name"], f"0x{s['virtual_address']:08X}",
                        s["raw_size"], f"0x{s['raw_pointer']:08X}",
                        chars, f"{s['entropy']:.3f}"
                    )
                )
                assessment = "Likely packed/compressed" if s["entropy"] >= 7.2 else (
                    "High entropy" if s["entropy"] >= 6.8 else "Normal"
                )
                self.ent_tree.insert(
                    "", "end",
                    values=(s["name"], s["raw_size"], f"{s['entropy']:.3f}", assessment)
                )

            for item in self.imp_tree.get_children():
                self.imp_tree.delete(item)
            for dll, funcs in self.pe.imports:
                self.imp_tree.insert(
                    "", "end",
                    values=(dll, ", ".join(funcs[:200]) + (" ..." if len(funcs) > 200 else ""))
                )

        strings = ascii_strings(self.data) + unicode_strings(self.data)
        strings = list(dict.fromkeys(strings))
        self.set_text(self.str_box, "\n".join(strings[:20000]))

        hex_lines = []
        for off in range(0, min(len(self.data), 16384), 16):
            chunk = self.data[off:off + 16]
            hx = " ".join(f"{b:02X}" for b in chunk)
            text = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
            hex_lines.append(f"{off:08X}  {hx:<47}  {text}")
        self.set_text(self.hex_box, "\n".join(hex_lines))

        if self.pe:
            findings = Analyzer(self.path, self.data, self.pe).heuristic_lines()
        else:
            findings = ["No PE structure detected; generic binary analysis only."]
        self.set_text(
            self.heur_box,
            "HEURISTIC TRIAGE\n"
            "================\n\n" +
            "\n".join("• " + x for x in findings) +
            "\n\nNote: Heuristic indicators are not proof of malware."
        )


if __name__ == "__main__":
    App().mainloop()
