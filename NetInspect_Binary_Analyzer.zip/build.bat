@echo off
setlocal
echo ==========================================
echo NetInspect Binary Analyzer - Build
echo ==========================================
echo.

python --version
if errorlevel 1 (
    echo [ERROR] Python was not found.
    echo Install Python 3.10+ and enable "Add Python to PATH".
    goto END
)

python -m pip install --upgrade pyinstaller
if errorlevel 1 (
    echo [ERROR] PyInstaller installation failed.
    goto END
)

pyinstaller --clean --noconfirm --onefile --windowed ^
  --name "NetInspect-Binary-Analyzer" main.py

if errorlevel 1 (
    echo.
    echo [ERROR] Build failed.
    goto END
)

echo.
echo ==========================================
echo BUILD SUCCESSFUL
echo ==========================================
echo EXE: %CD%\dist\NetInspect-Binary-Analyzer.exe

:END
echo.
pause
endlocal
