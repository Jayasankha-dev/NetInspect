# NetInspect Binary Analyzer 2.0

Defensive Windows PE triage and controlled runtime network observation.

## Included

- MD5 / SHA-256
- PE32 / PE32+ header information
- Sections and entropy
- Imports with selectable DLL analysis
- Export names
- ASCII and UTF-16LE strings
- Hex preview
- Heuristic triage
- Automated Windows checks:
  - VersionInfo
  - Authenticode signature
  - tasklist
  - netstat
  - local EXE/DLL/SYS/ASI inventory and SHA-256
- Runtime Network tab for an explicitly selected EXE
- Full JSON / HTML / TXT export

## Install

```bat
py -m pip install -r requirements.txt
```

## Run

```bat
py netinspect.py
```

## Build

```bat
py -m pip install pyinstaller psutil
pyinstaller --clean --noconfirm --onefile --windowed --name NetInspect-Binary-Analyzer netinspect.py
```

The executable is created under `dist\`.

## DLL workflow

In **Imports**, select a DLL. **Analyze Selected DLL** checks the analyzed program's directory,
System32, and SysWOW64. If the DLL is not found locally, use **Open File** to select it manually.

## Runtime note

The Runtime Network tab executes the selected EXE and observes connections visible for that
process and its child processes during the selected time window. Use it only for software
you are authorized to execute.

No live connection at a particular moment does not prove that a program never communicates.
Static imports also indicate capability, not proof of actual network activity.
