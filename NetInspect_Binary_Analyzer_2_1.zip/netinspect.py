
import hashlib
import json
import math
import os
import re
import struct
import subprocess
import threading
import time
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

APP_NAME = "NetInspect Binary Analyzer"
APP_VERSION = "2.0.0"

try:
    import psutil
except ImportError:
    psutil = None


def entropy(data: bytes) -> float:
    if not data:
        return 0.0
    counts = [0] * 256
    for b in data:
        counts[b] += 1
    n = len(data)
    return -sum((c / n) * math.log2(c / n) for c in counts if c)


def hash_file(path, algorithm="sha256"):
    h = hashlib.new(algorithm)
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def ascii_strings(data, minimum=4):
    return [m.decode("latin-1", errors="replace")
            for m in re.compile(rb"[\x20-\x7e]{%d,}" % minimum).findall(data)]


def unicode_strings(data, minimum=4):
    pat = re.compile(rb"(?:[\x20-\x7e]\x00){%d,}" % minimum)
    out = []
    for m in pat.findall(data):
        try:
            out.append(m.decode("utf-16le", errors="replace"))
        except Exception:
            pass
    return out


def safe_read(data, offset, size):
    if offset < 0 or size < 0 or offset + size > len(data):
        return None
    return data[offset:offset + size]


def u16(data, off):
    x = safe_read(data, off, 2)
    return struct.unpack("<H", x)[0] if x else None


def u32(data, off):
    x = safe_read(data, off, 4)
    return struct.unpack("<I", x)[0] if x else None


def u64(data, off):
    x = safe_read(data, off, 8)
    return struct.unpack("<Q", x)[0] if x else None


def cstr(data, off, max_len=512):
    if off is None or off < 0 or off >= len(data):
        return ""
    end = data.find(b"\x00", off, min(len(data), off + max_len))
    if end < 0:
        end = min(len(data), off + max_len)
    return data[off:end].decode("latin-1", errors="replace")


def rva_to_offset(sections, rva):
    for s in sections:
        va = s["virtual_address"]
        raw = s["raw_size"]
        if va <= rva < va + max(s["virtual_size"], raw):
            delta = rva - va
            if delta < raw:
                return s["raw_pointer"] + delta
    return None


class PEParser:
    def __init__(self, data):
        self.data = data
        self.sections = []
        self.info = {}
        self.imports = []
        self.exports = []
        self.parse()

    def parse(self):
        d = self.data
        if len(d) < 0x40 or d[:2] != b"MZ":
            raise ValueError("Not a valid DOS/PE file: missing MZ header.")

        pe_off = u32(d, 0x3C)
        if pe_off is None or safe_read(d, pe_off, 4) != b"PE\x00\x00":
            raise ValueError("Invalid PE signature.")

        coff = pe_off + 4
        machine = u16(d, coff)
        section_count = u16(d, coff + 2)
        timestamp = u32(d, coff + 4)
        opt_size = u16(d, coff + 16)
        characteristics = u16(d, coff + 18)
        opt = coff + 20

        magic = u16(d, opt)
        is64 = magic == 0x20B
        is32 = magic == 0x10B
        if not (is32 or is64):
            raise ValueError("Unsupported PE optional-header magic.")

        entry_rva = u32(d, opt + 16)
        image_base = u64(d, opt + 24) if is64 else u32(d, opt + 28)
        image_size = u32(d, opt + 56)
        subsystem = u16(d, opt + 68)
        dll_chars = u16(d, opt + 70)

        data_dir = opt + (112 if is64 else 96)
        export_rva = u32(d, data_dir) or 0
        export_size = u32(d, data_dir + 4) or 0
        import_rva = u32(d, data_dir + 8) or 0
        import_size = u32(d, data_dir + 12) or 0
        resource_rva = u32(d, data_dir + 16) or 0
        resource_size = u32(d, data_dir + 20) or 0
        security_rva = u32(d, data_dir + 32) or 0
        security_size = u32(d, data_dir + 36) or 0

        sec_off = opt + opt_size
        for i in range(section_count):
            off = sec_off + i * 40
            raw = safe_read(d, off, 40)
            if not raw:
                break
            name = raw[:8].split(b"\x00", 1)[0].decode("latin-1", errors="replace")
            virtual_size = u32(raw, 8) or 0
            virtual_address = u32(raw, 12) or 0
            raw_size = u32(raw, 16) or 0
            raw_pointer = u32(raw, 20) or 0
            chars = u32(raw, 36) or 0
            blob = safe_read(d, raw_pointer,
                             min(raw_size, max(0, len(d) - raw_pointer))) or b""
            self.sections.append({
                "name": name,
                "virtual_size": virtual_size,
                "virtual_address": virtual_address,
                "raw_size": raw_size,
                "raw_pointer": raw_pointer,
                "characteristics": chars,
                "entropy": entropy(blob),
            })

        self.info = {
            "Machine": {0x14C: "Intel 386 (I386)", 0x8664: "x64",
                        0x1C0: "ARM", 0xAA64: "ARM64"}.get(machine, f"0x{machine:04X}"),
            "Architecture": "PE32+" if is64 else "PE32",
            "Sections": section_count,
            "Entry Point RVA": f"0x{entry_rva:08X}",
            "Image Base": f"0x{image_base:X}",
            "Image Size": f"0x{image_size:X}",
            "Subsystem": {2: "Windows GUI", 3: "Windows Console",
                          9: "Windows CE", 10: "EFI Application"}.get(subsystem, str(subsystem)),
            "Characteristics": f"0x{characteristics:04X}",
            "DLL Characteristics": f"0x{dll_chars:04X}",
            "TimeDateStamp": timestamp,
            "Import RVA": f"0x{import_rva:08X}",
            "Import Size": f"0x{import_size:08X}",
            "Export RVA": f"0x{export_rva:08X}",
            "Export Size": f"0x{export_size:08X}",
            "Resource RVA": f"0x{resource_rva:08X}",
            "Resource Size": f"0x{resource_size:08X}",
            "Security Directory RVA": f"0x{security_rva:08X}",
            "Security Directory Size": f"0x{security_size:08X}",
            "Signed Image Directory Present": bool(security_rva and security_size),
        }

        if import_rva:
            self.parse_imports(import_rva, is64)
        if export_rva:
            self.parse_exports(export_rva)

    def parse_imports(self, rva, is64):
        off = rva_to_offset(self.sections, rva)
        if off is None:
            return
        step = 8 if is64 else 4
        for _ in range(512):
            desc = safe_read(self.data, off, 20)
            if not desc:
                break
            oft = u32(desc, 0) or 0
            name_rva = u32(desc, 12) or 0
            ft = u32(desc, 16) or 0
            if not (oft or name_rva or ft):
                break

            name_off = rva_to_offset(self.sections, name_rva)
            dll = cstr(self.data, name_off) if name_off is not None else "Unknown"
            funcs = []
            thunk_off = rva_to_offset(self.sections, oft or ft)
            if thunk_off is not None:
                for j in range(2048):
                    pos = thunk_off + j * step
                    val = u64(self.data, pos) if is64 else u32(self.data, pos)
                    if val is None or val == 0:
                        break
                    ordinal_flag = (1 << 63) if is64 else (1 << 31)
                    if val & ordinal_flag:
                        funcs.append(f"Ordinal #{val & 0xFFFF}")
                    else:
                        name_ptr = rva_to_offset(self.sections, int(val))
                        funcs.append(cstr(self.data, name_ptr + 2)
                                     if name_ptr is not None else "Unknown")
            self.imports.append((dll, funcs))
            off += 20

    def parse_exports(self, rva):
        off = rva_to_offset(self.sections, rva)
        blob = safe_read(self.data, off, 40) if off is not None else None
        if not blob:
            return
        name_count = u32(blob, 24) or 0
        name_rva = u32(blob, 32) or 0
        names_off = rva_to_offset(self.sections, name_rva)
        if names_off is None:
            return
        for i in range(min(name_count, 10000)):
            nrva = u32(self.data, names_off + i * 4)
            noff = rva_to_offset(self.sections, nrva) if nrva is not None else None
            if noff is not None:
                self.exports.append(cstr(self.data, noff))


class Analyzer:
    SUSPICIOUS_IMPORTS = {
        "VirtualAlloc", "VirtualProtect", "VirtualAllocEx", "VirtualProtectEx",
        "WriteProcessMemory", "ReadProcessMemory", "CreateRemoteThread",
        "NtWriteVirtualMemory", "NtCreateThreadEx", "QueueUserAPC",
        "WinExec", "ShellExecuteA", "ShellExecuteW",
        "URLDownloadToFileA", "URLDownloadToFileW",
        "InternetOpenA", "InternetOpenW", "InternetConnectA",
        "InternetConnectW", "WinHttpOpen", "WinHttpConnect",
        "WinHttpSendRequest", "RegSetValueExA", "RegSetValueExW",
        "CreateServiceA", "CreateServiceW", "CreateProcessA",
        "CreateProcessW", "OpenProcess", "SetWindowsHookExA",
        "SetWindowsHookExW",
    }
    NETWORK_IMPORTS = {
        "WSAStartup", "WSASocketA", "WSASocketW", "socket", "connect",
        "send", "recv", "InternetOpenA", "InternetOpenW",
        "InternetConnectA", "InternetConnectW", "HttpOpenRequestA",
        "HttpOpenRequestW", "WinHttpOpen", "WinHttpConnect",
        "WinHttpSendRequest", "URLDownloadToFileA", "URLDownloadToFileW",
        "getaddrinfo", "gethostbyname", "DnsQuery_A", "DnsQuery_W",
    }
    PACKER_HINTS = {
        "UPX": [b"UPX0", b"UPX1", b"UPX2"],
        "ASPack": [b".aspack", b"ASPack"],
        "Themida": [b".themida", b"Themida"],
        "VMProtect": [b".vmp", b"VMProtect"],
    }

    def __init__(self, path, data, pe=None):
        self.path, self.data, self.pe = path, data, pe

    def heuristic_lines(self):
        if not self.pe:
            return ["No PE structure detected; generic binary analysis only."]
        findings, score = [], 0
        high = [s for s in self.pe.sections if s["entropy"] >= 7.2]
        if high:
            findings.append("High-entropy section(s): " + ", ".join(s["name"] for s in high))
            score += min(20, len(high) * 10)

        imports = {fn for _, funcs in self.pe.imports for fn in funcs}
        hits = sorted(imports & self.SUSPICIOUS_IMPORTS)
        net = sorted(imports & self.NETWORK_IMPORTS)
        if hits:
            findings.append("Behavior-relevant imports: " + ", ".join(hits))
            score += min(35, len(hits) * 4)
        if net:
            findings.append("Network-capable imports: " + ", ".join(net))
            score += min(20, len(net) * 2)

        sec_names = {s["name"].lower() for s in self.pe.sections}
        for packer, hints in self.PACKER_HINTS.items():
            if any(h.lower() in sec_names or h in self.data for h in hints):
                findings.append(f"Packer/protector hint: {packer}")
                score += 10

        dc = int(self.pe.info.get("DLL Characteristics", "0"), 16)
        if dc & 0x40:
            findings.append("ASLR flag present")
        if dc & 0x100:
            findings.append("NX/DEP flag present")
        if dc & 0x4000:
            findings.append("Control Flow Guard flag present")
        if self.pe.info.get("Signed Image Directory Present"):
            findings.append("PE security directory is present; verify trust with the signature check.")
        if b"X5O!P%@AP" in self.data:
            findings.append("EICAR test signature found (test pattern, not malware).")
            score += 100

        level = "HIGH" if score >= 70 else "MEDIUM" if score >= 35 else "LOW"
        findings.insert(0, f"Heuristic risk score: {score}/100 ({level})")
        findings.append("Heuristic indicators are triage signals, not proof of malware.")
        return findings


def run_cmd(args, timeout=20):
    try:
        cp = subprocess.run(args, capture_output=True, text=True,
                            encoding="utf-8", errors="replace",
                            timeout=timeout, shell=False)
        return cp.returncode, (cp.stdout or "") + (("\n" + cp.stderr) if cp.stderr else "")
    except Exception as e:
        return -1, f"ERROR: {e}"


def powershell(script, *args, timeout=20):
    return run_cmd(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                    "-Command", script, *map(str, args)], timeout)


def get_version_info(path):
    script = r'''
$p = $args[0]
try {
  $v = (Get-Item -LiteralPath $p).VersionInfo
  [PSCustomObject]@{
    FileVersion=$v.FileVersion; ProductVersion=$v.ProductVersion
    CompanyName=$v.CompanyName; FileDescription=$v.FileDescription
    OriginalFilename=$v.OriginalFilename; ProductName=$v.ProductName
    LegalCopyright=$v.LegalCopyright; Language=$v.Language
  } | ConvertTo-Json -Compress
} catch { Write-Error $_ }
'''
    rc, out = powershell(script, path)
    if rc != 0:
        return {"error": out.strip()}
    try:
        return json.loads(out.strip())
    except Exception:
        return {"raw": out.strip()}


def get_signature(path):
    script = r'''
$p = $args[0]
try {
  $s = Get-AuthenticodeSignature -LiteralPath $p
  [PSCustomObject]@{
    Status=[string]$s.Status
    StatusMessage=[string]$s.StatusMessage
    SignerSubject=if($s.SignerCertificate){[string]$s.SignerCertificate.Subject}else{""}
    Issuer=if($s.SignerCertificate){[string]$s.SignerCertificate.Issuer}else{""}
    Thumbprint=if($s.SignerCertificate){[string]$s.SignerCertificate.Thumbprint}else{""}
    NotBefore=if($s.SignerCertificate){[string]$s.SignerCertificate.NotBefore}else{""}
    NotAfter=if($s.SignerCertificate){[string]$s.SignerCertificate.NotAfter}else{""}
  } | ConvertTo-Json -Compress
} catch { Write-Error $_ }
'''
    rc, out = powershell(script, path)
    if rc != 0:
        return {"error": out.strip()}
    try:
        return json.loads(out.strip())
    except Exception:
        return {"raw": out.strip()}


def tasklist_for_name(name):
    return run_cmd(["tasklist", "/FI", f"IMAGENAME eq {name}"])[1].strip()


def netstat_for_pid(pid):
    rc, out = run_cmd(["netstat", "-ano"])
    if rc != 0:
        return out
    rows = [x for x in out.splitlines() if x.strip().endswith(str(pid))]
    return "\n".join(rows) if rows else "No matching netstat rows."


def file_inventory(folder):
    rows = []
    try:
        for p in sorted(Path(folder).iterdir()):
            if p.is_file() and p.suffix.lower() in {
                ".exe", ".dll", ".sys", ".ocx", ".scr", ".com", ".asi"
            }:
                try:
                    rows.append({
                        "name": p.name, "path": str(p),
                        "size": p.stat().st_size,
                        "sha256": hash_file(p, "sha256")
                    })
                except Exception as e:
                    rows.append({"name": p.name, "path": str(p), "error": str(e)})
    except Exception as e:
        return [{"error": str(e)}]
    return rows


class RuntimeMonitor:
    def __init__(self, row_callback, status_callback):
        self.row_callback = row_callback
        self.status_callback = status_callback
        self.proc = None
        self.thread = None
        self.stop_event = threading.Event()
        self.rows = []

    def start(self, path, duration):
        if self.thread and self.thread.is_alive():
            raise RuntimeError("Runtime monitoring is already running.")
        self.stop_event.clear()
        self.rows = []

        def worker():
            try:
                self.proc = subprocess.Popen(
                    [path], cwd=os.path.dirname(path) or None,
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    shell=False
                )
                root_pid = self.proc.pid
                self.status_callback(f"Running {os.path.basename(path)} | PID {root_pid}")
                deadline = time.time() + duration

                while not self.stop_event.is_set() and time.time() < deadline:
                    pids = {root_pid}
                    if psutil is not None:
                        try:
                            pids.update(c.pid for c in psutil.Process(root_pid).children(recursive=True))
                        except Exception:
                            pass

                    snapshot = []
                    if psutil is not None:
                        for pid in sorted(pids):
                            try:
                                proc = psutil.Process(pid)
                                for c in proc.net_connections(kind="inet"):
                                    if not c.raddr:
                                        continue
                                    local = f"{c.laddr.ip}:{c.laddr.port}" if c.laddr else ""
                                    remote = f"{c.raddr.ip}:{c.raddr.port}"
                                    snapshot.append({
                                        "timestamp": datetime.now().isoformat(timespec="seconds"),
                                        "pid": pid, "process": proc.name(),
                                        "local": local, "remote": remote,
                                        "status": c.status,
                                        "family": str(c.family), "type": str(c.type)
                                    })
                            except (psutil.NoSuchProcess, psutil.AccessDenied):
                                pass

                    for row in snapshot:
                        key = tuple(row[k] for k in ("pid", "local", "remote", "status"))
                        if not any(tuple(x[k] for k in ("pid", "local", "remote", "status")) == key
                                   for x in self.rows):
                            self.rows.append(row)
                            self.row_callback(row)

                    if self.proc.poll() is not None:
                        self.status_callback(f"Target exited with code {self.proc.returncode}.")
                        break
                    time.sleep(1)

                if self.proc and self.proc.poll() is None:
                    self.status_callback(
                        "Monitoring stopped/window ended; target process was left running."
                    )
            except Exception as e:
                self.status_callback(f"Runtime error: {e}")
            finally:
                self.proc = None

        self.thread = threading.Thread(target=worker, daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()

    def terminate(self):
        if not self.proc:
            return False
        try:
            if psutil is not None:
                p = psutil.Process(self.proc.pid)
                for child in p.children(recursive=True):
                    try:
                        child.terminate()
                    except Exception:
                        pass
                p.terminate()
            else:
                self.proc.terminate()
            return True
        except Exception:
            return False


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} | {APP_VERSION}")
        self.geometry("1450x900")
        self.minsize(1100, 720)
        self.configure(bg="#151515")

        self.path = None
        self.data = b""
        self.pe = None
        self.static = {}
        self.runtime = RuntimeMonitor(self.add_runtime_row, self.runtime_status)
        self.build_ui()

    def style(self):
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure("TNotebook", background="#151515", borderwidth=0)
        s.configure("TNotebook.Tab", background="#303030", foreground="#ddd", padding=(14, 7))
        s.map("TNotebook.Tab", background=[("selected", "#168bd1")])
        s.configure("Treeview", background="#202020", foreground="#ddd",
                    fieldbackground="#202020", rowheight=24)
        s.configure("Treeview.Heading", background="#303030", foreground="#00e6c3")
        s.map("Treeview", background=[("selected", "#087bc1")])

    def build_ui(self):
        self.style()
        top = tk.Frame(self, bg="#151515")
        top.pack(fill="x", padx=14, pady=10)

        tk.Label(top, text="◈", fg="#f2b544", bg="#151515",
                 font=("Segoe UI", 22, "bold")).pack(side="left", padx=(0, 8))
        tk.Label(top, text=APP_NAME, fg="#f0f0f0", bg="#151515",
                 font=("Segoe UI", 18, "bold")).pack(side="left")
        tk.Label(top, text="  Static Triage + Runtime Network Observation",
                 fg="#8f8f8f", bg="#151515", font=("Segoe UI", 10)).pack(side="left", pady=8)

        ttk.Button(top, text="Full Export", command=self.export_all).pack(side="right", padx=4)
        ttk.Button(top, text="Run Checks", command=self.run_checks).pack(side="right", padx=4)
        ttk.Button(top, text="Open File", command=self.open_file).pack(side="right", padx=4)
        ttk.Button(top, text="Clear", command=self.clear).pack(side="right", padx=4)

        self.path_var = tk.StringVar(value="No file selected")
        tk.Label(self, textvariable=self.path_var, anchor="w",
                 fg="#00e6c3", bg="#1c1c1c", padx=10, pady=7).pack(fill="x", padx=14)

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=14, pady=12)

        self.tabs = {}
        for title in ["File Info", "PE", "Sections", "Imports", "Strings",
                      "Hex", "Entropy", "Heuristics", "System Checks", "Runtime Network"]:
            self.tabs[title] = tk.Frame(self.notebook, bg="#171717")
            self.notebook.add(self.tabs[title], text=title)

        self.file_tab = self.tabs["File Info"]
        self.pe_tab = self.tabs["PE"]
        self.sec_tab = self.tabs["Sections"]
        self.imp_tab = self.tabs["Imports"]
        self.str_tab = self.tabs["Strings"]
        self.hex_tab = self.tabs["Hex"]
        self.ent_tab = self.tabs["Entropy"]
        self.heur_tab = self.tabs["Heuristics"]
        self.check_tab = self.tabs["System Checks"]
        self.run_tab = self.tabs["Runtime Network"]

        self.info_box = self.make_text(self.file_tab)
        self.pe_box = self.make_text(self.pe_tab)
        self.str_box = self.make_text(self.str_tab)
        self.hex_box = self.make_text(self.hex_tab)
        self.heur_box = self.make_text(self.heur_tab)
        self.check_box = self.make_text(self.check_tab)

        self.sec_tree = self.make_tree(
            self.sec_tab, ("Name", "VA", "Raw Size", "Raw Offset", "Characteristics", "Entropy")
        )
        self.ent_tree = self.make_tree(self.ent_tab, ("Section", "Size", "Entropy", "Assessment"))

        imp_frame = tk.Frame(self.imp_tab, bg="#171717")
        imp_frame.pack(fill="both", expand=True, padx=8, pady=8)
        left = tk.Frame(imp_frame, bg="#171717")
        right = tk.Frame(imp_frame, bg="#171717")
        left.pack(side="left", fill="both", expand=False, padx=(0, 8))
        right.pack(side="left", fill="both", expand=True)

        tk.Label(left, text="Imported DLLs", fg="#00e6c3", bg="#171717",
                 font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.dll_tree = ttk.Treeview(left, columns=("DLL",), show="headings",
                                     selectmode="browse", height=22)
        self.dll_tree.heading("DLL", text="DLL")
        self.dll_tree.column("DLL", width=280, anchor="w")
        self.dll_tree.pack(side="left", fill="both", expand=True)
        dy = ttk.Scrollbar(left, orient="vertical", command=self.dll_tree.yview)
        dy.pack(side="right", fill="y")
        self.dll_tree.configure(yscrollcommand=dy.set)
        self.dll_tree.bind("<<TreeviewSelect>>", self.show_selected_dll)
        ttk.Button(left, text="Analyze Selected DLL",
                   command=self.analyze_selected_dll).pack(fill="x", pady=(8, 0))

        tk.Label(right, text="Imported Functions", fg="#00e6c3", bg="#171717",
                 font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.dll_func_box = self.make_text(right)

        check_top = tk.Frame(self.check_tab, bg="#171717")
        check_top.pack(fill="x", padx=8, pady=8)
        ttk.Button(check_top, text="Run Automated Checks",
                   command=self.run_checks).pack(side="left")
        self.check_status = tk.StringVar(value="Ready")
        tk.Label(check_top, textvariable=self.check_status,
                 fg="#9e9e9e", bg="#171717").pack(side="left", padx=12)

        run_top = tk.Frame(self.run_tab, bg="#171717")
        run_top.pack(fill="x", padx=8, pady=8)
        tk.Label(run_top, text="Monitor seconds:", fg="#ddd", bg="#171717").pack(side="left")
        self.duration_var = tk.StringVar(value="60")
        tk.Entry(run_top, textvariable=self.duration_var, width=7,
                 bg="#111", fg="#ddd", insertbackground="#fff",
                 relief="flat").pack(side="left", padx=(5, 10))
        ttk.Button(run_top, text="Run Target + Monitor",
                   command=self.start_runtime).pack(side="left", padx=3)
        ttk.Button(run_top, text="Stop Monitoring",
                   command=self.stop_runtime).pack(side="left", padx=3)
        ttk.Button(run_top, text="Terminate Target",
                   command=self.terminate_runtime).pack(side="left", padx=3)
        ttk.Button(run_top, text="Clear Runtime",
                   command=self.clear_runtime).pack(side="left", padx=3)
        self.runtime_status_var = tk.StringVar(value="Ready")
        tk.Label(run_top, textvariable=self.runtime_status_var,
                 fg="#00e6c3", bg="#171717").pack(side="right")

        self.runtime_tree = self.make_tree(
            self.run_tab, ("Time", "PID", "Process", "Local", "Remote", "Status")
        )
        for col, width in {"Time":145, "PID":70, "Process":150, "Local":210,
                           "Remote":210, "Status":120}.items():
            self.runtime_tree.column(col, width=width)

        bottom = tk.Frame(self, bg="#151515")
        bottom.pack(fill="x", padx=14, pady=(0, 10))
        self.status_var = tk.StringVar(value="Ready")
        tk.Label(bottom, textvariable=self.status_var, fg="#9e9e9e",
                 bg="#151515", anchor="w").pack(side="left")

    def make_text(self, parent):
        frame = tk.Frame(parent, bg="#171717")
        frame.pack(fill="both", expand=True, padx=8, pady=8)
        box = tk.Text(frame, bg="#111", fg="#ddd", insertbackground="#fff",
                      font=("Consolas", 10), wrap="none", relief="flat")
        sy = ttk.Scrollbar(frame, orient="vertical", command=box.yview)
        sx = ttk.Scrollbar(frame, orient="horizontal", command=box.xview)
        box.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        box.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return box

    def make_tree(self, parent, columns):
        frame = tk.Frame(parent, bg="#171717")
        frame.pack(fill="both", expand=True, padx=8, pady=8)
        tree = ttk.Treeview(frame, columns=columns, show="headings")
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=170, anchor="w")
        y = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        x = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=y.set, xscrollcommand=x.set)
        tree.grid(row=0, column=0, sticky="nsew")
        y.grid(row=0, column=1, sticky="ns")
        x.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return tree

    def open_file(self):
        path = filedialog.askopenfilename(
            title="Select a file",
            filetypes=[("Executable / Binary",
                        "*.exe *.dll *.sys *.ocx *.scr *.com *.asi *.bin"),
                       ("All files", "*.*")]
        )
        if path:
            self.analyze(path)

    def clear(self):
        self.path = None
        self.data = b""
        self.pe = None
        self.static = {}
        self.path_var.set("No file selected")
        for box in [self.info_box, self.pe_box, self.str_box, self.hex_box,
                    self.heur_box, self.check_box, self.dll_func_box]:
            box.delete("1.0", "end")
        for tree in [self.sec_tree, self.ent_tree, self.dll_tree]:
            for item in tree.get_children():
                tree.delete(item)
        self.check_status.set("Ready")
        self.status_var.set("Ready")

    def analyze(self, path):
        try:
            with open(path, "rb") as f:
                self.data = f.read()
            self.path = os.path.abspath(path)
            self.pe = PEParser(self.data) if self.data[:2] == b"MZ" else None
            self.populate()
            self.status_var.set(f"Analyzed {os.path.basename(path)} | {len(self.data):,} bytes")
            self.notebook.select(self.file_tab)
        except Exception as e:
            messagebox.showerror("Analysis Error", str(e))
            self.status_var.set("Analysis failed")

    def set_text(self, box, text):
        box.delete("1.0", "end")
        box.insert("1.0", text)

    def populate(self):
        size = len(self.data)
        strings = list(dict.fromkeys(ascii_strings(self.data) + unicode_strings(self.data)))

        file_info = {
            "name": os.path.basename(self.path), "full_path": self.path,
            "size": size, "size_mib": round(size / 1048576, 3),
            "md5": hash_file(self.path, "md5"),
            "sha256": hash_file(self.path, "sha256"),
            "entropy": round(entropy(self.data), 6),
            "type": "PE executable" if self.pe else "Unknown / non-PE",
        }
        self.static = {
            "application": {"name": APP_NAME, "version": APP_VERSION},
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "target": self.path, "file_info": file_info
        }

        self.set_text(self.info_box, "\n".join([
            f"File name       : {file_info['name']}",
            f"Full path       : {file_info['full_path']}",
            f"File size       : {size:,} bytes ({size / 1048576:.2f} MiB)",
            f"MD5             : {file_info['md5']}",
            f"SHA-256         : {file_info['sha256']}",
            f"Overall entropy : {file_info['entropy']:.4f}",
            f"File type       : {file_info['type']}",
        ]))

        for tree in [self.sec_tree, self.ent_tree, self.dll_tree]:
            for item in tree.get_children():
                tree.delete(item)

        if self.pe:
            self.set_text(self.pe_box, "\n".join(f"{k:28}: {v}"
                                                 for k, v in self.pe.info.items()))
            for s in self.pe.sections:
                chars = f"0x{s['characteristics']:08X}"
                self.sec_tree.insert("", "end", values=(
                    s["name"], f"0x{s['virtual_address']:08X}", s["raw_size"],
                    f"0x{s['raw_pointer']:08X}", chars, f"{s['entropy']:.3f}"
                ))
                assessment = ("Likely packed/compressed" if s["entropy"] >= 7.2
                              else "High entropy" if s["entropy"] >= 6.8 else "Normal")
                self.ent_tree.insert("", "end",
                                     values=(s["name"], s["raw_size"],
                                             f"{s['entropy']:.3f}", assessment))
            for dll, _ in self.pe.imports:
                self.dll_tree.insert("", "end", iid=dll, values=(dll,))

        self.set_text(self.str_box, "\n".join(strings[:30000]))
        hex_lines = []
        for off in range(0, min(len(self.data), 32768), 16):
            chunk = self.data[off:off + 16]
            hx = " ".join(f"{b:02X}" for b in chunk)
            text = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
            hex_lines.append(f"{off:08X}  {hx:<47}  {text}")
        self.set_text(self.hex_box, "\n".join(hex_lines))

        findings = Analyzer(self.path, self.data, self.pe).heuristic_lines() \
            if self.pe else ["No PE structure detected; generic binary analysis only."]
        self.set_text(self.heur_box,
                      "HEURISTIC TRIAGE\n================\n\n" +
                      "\n".join("• " + x for x in findings))

        self.static["pe"] = self.pe.info if self.pe else None
        self.static["sections"] = self.pe.sections if self.pe else []
        self.static["imports"] = [{"dll": d, "functions": f}
                                  for d, f in self.pe.imports] if self.pe else []
        self.static["exports"] = self.pe.exports if self.pe else []
        self.static["strings_count"] = len(strings)
        self.static["heuristics"] = findings

    def show_selected_dll(self, _event=None):
        sel = self.dll_tree.selection()
        if not sel or not self.pe:
            return
        name = sel[0]
        for dll, funcs in self.pe.imports:
            if dll == name:
                self.set_text(self.dll_func_box,
                              f"DLL: {dll}\nImported function count: {len(funcs)}\n\n" +
                              "\n".join(funcs))
                return

    def analyze_selected_dll(self):
        sel = self.dll_tree.selection()
        if not sel:
            messagebox.showinfo("Select DLL", "Select an imported DLL first.")
            return
        name = sel[0]
        base = os.path.dirname(self.path) if self.path else ""
        root = os.environ.get("SystemRoot", r"C:\Windows")
        candidates = [os.path.join(base, name),
                      os.path.join(root, "System32", name),
                      os.path.join(root, "SysWOW64", name)]
        target = next((p for p in candidates if os.path.isfile(p)), None)
        if not target:
            messagebox.showinfo(
                "DLL not found",
                f"'{name}' is imported by the selected file, but a local copy "
                "was not found in the analyzed directory/System32/SysWOW64.\n\n"
                "Use Open File to select the DLL manually."
            )
            return
        self.analyze(target)

    def run_checks(self):
        if not self.path:
            messagebox.showinfo("No file", "Open an EXE/DLL first.")
            return
        self.check_status.set("Running automated Windows checks...")
        self.notebook.select(self.check_tab)

        def worker():
            result = {
                "target": self.path,
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "md5": hash_file(self.path, "md5"),
                "sha256": hash_file(self.path, "sha256"),
                "version_info": get_version_info(self.path),
                "signature": get_signature(self.path),
                "tasklist": tasklist_for_name(os.path.basename(self.path)),
                "directory_inventory": file_inventory(os.path.dirname(self.path)),
            }
            pids = []
            if psutil:
                for p in psutil.process_iter(["pid", "name", "exe"]):
                    try:
                        if (p.info.get("name") or "").lower() == os.path.basename(self.path).lower():
                            pids.append(p.info["pid"])
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
            result["running_pids"] = pids
            result["netstat_by_pid"] = {str(pid): netstat_for_pid(pid) for pid in pids}
            self.static["system_checks"] = result

            def update():
                parts = [
                    "AUTOMATED SYSTEM CHECKS", "======================", "",
                    f"Target: {self.path}", f"Time: {result['timestamp']}", "",
                    f"MD5: {result['md5']}", f"SHA256: {result['sha256']}", "",
                    "VERSION INFO", "------------",
                    json.dumps(result["version_info"], indent=2, ensure_ascii=False), "",
                    "DIGITAL SIGNATURE", "-----------------",
                    json.dumps(result["signature"], indent=2, ensure_ascii=False), "",
                    "TASKLIST", "--------", result["tasklist"], "",
                    f"RUNNING PIDs: {result['running_pids']}", "",
                    "NETSTAT", "-------"
                ]
                if result["netstat_by_pid"]:
                    for pid, rows in result["netstat_by_pid"].items():
                        parts.append(f"[PID {pid}]\n{rows}")
                else:
                    parts.append("No matching running PID; no current connection rows were checked.")
                parts += [
                    "", "LOCAL EXE/DLL/SYS/ASI INVENTORY",
                    "-------------------------------",
                    json.dumps(result["directory_inventory"], indent=2, ensure_ascii=False),
                    "", "Note: no connection at one moment does NOT prove that a program "
                    "never communicates. Runtime observation is time-window based."
                ]
                self.set_text(self.check_box, "\n".join(parts))
                self.check_status.set("Checks completed.")
                self.status_var.set("Automated checks completed.")
            self.after(0, update)

        threading.Thread(target=worker, daemon=True).start()

    def runtime_status(self, text):
        self.after(0, lambda: self.runtime_status_var.set(text))

    def add_runtime_row(self, row):
        def add():
            self.runtime_tree.insert("", "end", values=(
                row["timestamp"], row["pid"], row["process"],
                row["local"], row["remote"], row["status"]
            ))
            children = self.runtime_tree.get_children()
            if children:
                self.runtime_tree.see(children[-1])
        self.after(0, add)

    def start_runtime(self):
        if not self.path:
            messagebox.showinfo("No target", "Open an EXE first.")
            return
        if not self.path.lower().endswith(".exe"):
            messagebox.showinfo("Runtime target",
                                "Runtime execution is for EXE files. DLLs remain static-analysis targets.")
            return
        try:
            seconds = max(1, min(3600, int(self.duration_var.get())))
        except ValueError:
            messagebox.showerror("Invalid duration", "Enter 1-3600 seconds.")
            return
        self.notebook.select(self.run_tab)
        try:
            self.runtime.start(self.path, seconds)
        except Exception as e:
            messagebox.showerror("Runtime", str(e))

    def stop_runtime(self):
        self.runtime.stop()

    def terminate_runtime(self):
        self.runtime_status_var.set(
            "Terminate requested." if self.runtime.terminate()
            else "No active target."
        )

    def clear_runtime(self):
        for item in self.runtime_tree.get_children():
            self.runtime_tree.delete(item)
        self.runtime.rows = []
        self.runtime_status_var.set("Runtime table cleared.")

    def export_all(self):
        if not self.path:
            messagebox.showinfo("No file", "Analyze a file first.")
            return
        report = dict(self.static)
        report["runtime_network"] = list(self.runtime.rows)
        base = Path(self.path).stem
        out = filedialog.asksaveasfilename(
            title="Export full analysis", initialfile=f"{base}_NetInspect_Report.json",
            defaultextension=".json",
            filetypes=[("JSON report", "*.json"), ("HTML report", "*.html"),
                       ("Text report", "*.txt")]
        )
        if not out:
            return
        try:
            ext = Path(out).suffix.lower()
            payload = json.dumps(report, indent=2, ensure_ascii=False)
            if ext == ".html":
                safe = payload.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                content = (
                    "<!doctype html><html><head><meta charset='utf-8'>"
                    f"<title>{base} - NetInspect</title>"
                    "<style>body{background:#111;color:#ddd;font-family:Consolas,monospace;padding:24px}"
                    "pre{white-space:pre-wrap;background:#181818;padding:18px;border-radius:8px}"
                    "h1{color:#00e6c3}</style></head><body>"
                    "<h1>NetInspect Binary Analyzer</h1>"
                    f"<p>Target: {self.path}</p><pre>{safe}</pre></body></html>"
                )
            else:
                content = payload
            Path(out).write_text(content, encoding="utf-8")
            self.status_var.set(f"Exported: {os.path.basename(out)}")
            messagebox.showinfo("Export complete", f"Full report saved to:\n{out}")
        except Exception as e:
            messagebox.showerror("Export error", str(e))


if __name__ == "__main__":
    App().mainloop()
